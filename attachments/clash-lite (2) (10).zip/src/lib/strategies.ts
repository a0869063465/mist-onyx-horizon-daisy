import { monsterCard, spellCard } from "./catalog.ts";

const KEY = "clash-strategies";

export const BUILTIN_STRATEGIES: Strategy[] = [
  {
    id: "sau-buom",
    name: "Sâu bướm tiến hoá",
    cards: ["chan-ken", "ken-ngai", "sau-non", "ngai-khong-lo", "ngai-nu-hoang", "ngai-hoan-my"],
    text: "Sâu bướm yếu ớt, bọc kén và chui ra, thành phiên bản khác cực kỳ mạnh mẽ.",
    source: "Haga vs Yugi (anime tập 4)",
  },
  {
    id: "bien-sau-plan",
    name: "Biển sâu",
    cards: ["kraken", "sua-hut-ma-phap", "trai-tim-hai-long", "bien-sau"],
    text: "Các quái thú ẩn mình dưới biển sâu.\nBạn không có thông tin gì về chúng, hãy phá chiến thuật, hoặc trông cậy vào vận may của mình.",
    source: "Trận chiến Yami Yugi VS Tsunami (Tập 7 Anime)",
  },
  {
    id: "nang-cap",
    name: "Nâng cấp quái thú",
    cards: ["te-giac-be-con", "te-giac-hieu-thang", "te-giac-chien-binh"],
    text: "Quái thú chiến đấu, mạnh lên theo từng lượt.",
    source: "",
  },
  {
    id: "tinh-ban",
    name: "Tình bạn cao đẹp",
    cards: ["kazura", "kizuran"],
    text: "Hai quái thú tương trợ lẫn nhau, càng quét chiến trường",
    source: "Joey vs Rex rapter (Anime tập 13)",
  },
  {
    id: "cong-thu",
    name: "Công thủ linh hoạt",
    cards: ["rong-boc-trung"],
    text: "Chuyển đổi công hay thủ tuỳ tình huống",
    source: "Vegasasu, vs yugi (manga đảo đấu bài)",
  },
  {
    id: "ke-uoc",
    name: "Kế ước với quỷ",
    cards: ["trieu-hoi-ac-ma"],
    text: "Hiến tế linh hồn để huỷ diệt đối thủ từ sớm",
    source: "Yugi, vs Ngài lv3 (haga), vs Tam thần (Ae mê cung)",
  },
  {
    id: "xuyen-kich",
    name: "Xuyên kích",
    cards: ["ky-si-bong-toi"],
    text: "Chuyên xuyên kích quái có sức phòng ngự cao.",
    source: "Yugi, vs Gã hề (Kaiba tháp game), vs kén ngài (Haga đảo đấu bài)",
  },
  {
    id: "buff",
    name: "Buff và Hỗ trợ",
    cards: ["yeu-tinh-chuc-phuc"],
    text: "Buff chỉ số và máu cho đồng đội.",
    source: "Yugi, vs Kaiba (manga lần đầu gặp), vs (ma nhân rối và Mokuba, đảo đấu bài)",
  },
  {
    id: "xuat-chung",
    name: "Chiến binh xuất chúng",
    cards: ["kiem-si-lua-thieng"],
    text: "1 mình hắn, hạ liên tiếp 3 quái thú khủng long.",
    source: "Joey vs Rex Rapter (Anime tập 13)",
  },
  {
    id: "ben-bi",
    name: "Giao tranh bền bỉ",
    cards: ["dau-si-bo-tot"],
    text: "Hắn có thể giúp bạn bền bỉ sống sót qua giai đoạn lv3",
    source: "Kaiba, vs joey (anime tập 16)",
  },
  {
    id: "sat-da",
    name: "Phòng ngự sắt đá",
    cards: ["linh-chien-da-khong-lo"],
    text: "Mình hắn có thể che chắn toàn diện cho bạn.",
    source: "Yugi, vs Tsunami (Anime tập 7)",
  },
  {
    id: "xuyen-phong",
    name: "Xuyên phòng ngự",
    cards: ["khung-long-vay-kiem"],
    text: "Gặp hàng vòng ngự quá chắc chắn, không cần phải lo.",
    source: "",
  },
  {
    id: "an-mon",
    name: "Ăn mòn quái thú",
    cards: ["mo-voi-ma-mut"],
    text: "Ma mút nguyền rủa kẻ thù, khiến hắn chịu lời nguyền và chết dần theo từng lượt.",
    source: "Yami yugi vs Kaiba (Đảo đấu bài, Manga)",
  },
  {
    id: "soi-roi",
    name: "Bóng tối soi rọi",
    cards: ["rong-phun-hoa-cau"],
    text: "Dùng để soi sáng, lấy thông tin địch thủ ẩn nấp.\nCũng dùng như 1 lựa chọn dame phép trung bình",
    source: "Yugi vs kaiba Tháp game, vs sát thủ đảo đấu bài (Anime tập 15)",
  },
  {
    id: "qua-cam",
    name: "Chiến binh quả cảm",
    cards: ["chien-si-gam-nham"],
    text: "Chú chuột phòng ngự kéo dài suốt giai đoạn lv 2 cực kỳ bền bỉ.",
    source: "",
  },
  {
    id: "dong-quy",
    name: "Đồng quy",
    cards: ["ong-khong-lo"],
    text: "Chết cùng kẻ thù, hoặc làm nó tê liệt.",
    source: "Haga, vs yugi (Anime tập 3)",
  },
  {
    id: "cap-so",
    name: "Cấp số nhân",
    cards: ["cuc-bong-ma-quai"],
    text: "Huỷ diệt nhiều đơn vị yếu máu.",
    source: "Yugi vs Kaiba (manga đảo đấu bài), vs Vegasasu.",
  },
  {
    id: "huy-diet",
    name: "Huỷ diệt và tiến hoá",
    cards: ["phu-thuy-thoi-gian"],
    text: "Huỷ diệt đối thủ\nTiến hoá vượt trội đồng minh",
    source: "Joey vs hầu hết các trận đấu.",
  },
  {
    id: "nhieu-mana",
    name: "Nhiều mana hơn",
    cards: ["quai-thu-thien-su"],
    text: "Rất tiện đầu game, lấy nhiều mana làm nhiều việc hơn, mạnh sớm hơn đối thủ.",
    source: "",
  },
  {
    id: "nhoi-con",
    name: "Nhõi con ức chế",
    cards: ["tho-den-tinh-nghich"],
    text: "Bạn cầm quái lv 3, nhưng không thể làm gì thằng nhóc lv 1.",
    source: "Vegasasu vs Kaiba (Manga đâor đấu bài)",
  },
  {
    id: "ban-so",
    name: "Phép thuật ban sơ",
    cards: ["phu-thuy-ti-hon"],
    text: "Tấn công phép từ sớm, nhưng late vẫn không đuối sát thương.",
    source: "",
  },
  {
    id: "tich-luy",
    name: "Tích luỹ năng lượng",
    cards: ["ga-he-dang-so"],
    text: "Tích luỹ qua nhiều lượt, rồi bùng phát.",
    source: "Kaiba vs Yugi (Manga, Tầng 5 Tháp trò chơi)",
  },
];

export type Strategy = {
  id: string;
  name: string;
  cards: string[];
  text: string;
  source: string;
};

export function sortCards(ids: string[]): string[] {
  return [...ids].sort((a, b) => {
    const left = monsterCard(a);
    const right = monsterCard(b);
    if (left && right) return left.stars - right.stars || left.name.localeCompare(right.name, "vi");
    if (left) return -1;
    if (right) return 1;
    const spellA = spellCard(a);
    const spellB = spellCard(b);
    return (spellA?.gems ?? 0) - (spellB?.gems ?? 0) || (spellA?.name ?? a).localeCompare(spellB?.name ?? b, "vi");
  });
}

function topStars(ids: string[]) {
  return Math.max(0, ...ids.map((id) => monsterCard(id)?.stars ?? 0));
}

export function sortStrategies(list: Strategy[]): Strategy[] {
  return [...list].sort((a, b) => {
    const count = b.cards.length - a.cards.length;
    if (count) return count;
    const stars = topStars(b.cards) - topStars(a.cards);
    if (stars) return stars;
    return a.name.localeCompare(b.name, "vi");
  });
}

function clean(raw: unknown): Strategy[] {
  if (!Array.isArray(raw)) return [];
  return raw.flatMap((item) => {
    if (!item || typeof item !== "object") return [];
    const row = item as Partial<Strategy>;
    if (typeof row.id !== "string" || typeof row.name !== "string") return [];
    const cards = Array.isArray(row.cards) ? row.cards.filter((id) => typeof id === "string" && (monsterCard(id) || spellCard(id))) : [];
    return [{ id: row.id, name: row.name, cards, text: typeof row.text === "string" ? row.text : "", source: typeof row.source === "string" ? row.source : "" }];
  });
}

export function loadStrategies(): Strategy[] {
  if (typeof localStorage === "undefined") return BUILTIN_STRATEGIES;
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return BUILTIN_STRATEGIES;
    const saved = clean(JSON.parse(raw));
    return saved.length ? saved : BUILTIN_STRATEGIES;
  } catch {
    return BUILTIN_STRATEGIES;
  }
}

export function saveStrategies(list: Strategy[]) {
  localStorage.setItem(KEY, JSON.stringify(list));
}
