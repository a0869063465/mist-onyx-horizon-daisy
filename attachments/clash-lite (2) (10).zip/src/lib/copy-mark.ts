export function plainCopy(text: string) {
  return text.replaceAll("**", "").replaceAll("__", "");
}

export type CopyBit = { text: string; bold: boolean; under: boolean } | { br: true };

export function parseCopy(raw: string): CopyBit[] {
  const out: CopyBit[] = [];
  let bold = false;
  let under = false;
  for (const bit of raw.split(/(\*\*|__|\n)/)) {
    if (bit === "**") bold = !bold;
    else if (bit === "__") under = !under;
    else if (bit === "\n") out.push({ br: true });
    else if (bit) out.push({ text: bit, bold, under });
  }
  return out;
}

const SIZE_KEY = "clash-copy-size";

export function loadCopySize() {
  if (typeof localStorage === "undefined") return 100;
  const next = Number(localStorage.getItem(SIZE_KEY));
  if (!Number.isFinite(next)) return 100;
  return Math.min(160, Math.max(70, Math.round(next)));
}

export function saveCopySize(size: number) {
  const next = Math.min(160, Math.max(70, Math.round(size)));
  localStorage.setItem(SIZE_KEY, String(next));
  applyCopySize(next);
  window.dispatchEvent(new Event("clash-copy-size"));
  return next;
}

export function applyCopySize(size = loadCopySize()) {
  if (typeof document === "undefined") return;
  document.documentElement.style.setProperty("--copy-size", String(size));
}

