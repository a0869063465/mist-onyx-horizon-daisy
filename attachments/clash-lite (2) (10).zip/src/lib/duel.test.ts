var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
import assert from "node:assert/strict";
import test from "node:test";
import {
  attackFace,
  attackMonster,
  castSpell,
  chronoHighAlly,
  createDuel,
  declareSkill,
  digGrave,
  draw,
  endTurn,
  fuse,
  passResponse,
  assignBlock,
  answerFairy,
  boostGnawOnChain,
  harpyOffer,
  harpyWard,
  harpyLash,
  evolveBird,
  answerPlume,
  pullReel,
  scoreReel,
  settleReel,
  skillLook,
  startReel,
  summon,
  testGrant,
  useSkill,
  wallAlly,
  answerLegs,
} from "./duel.ts";
import { FUSIONS, findFusion } from "./fusion.ts";
const COTTON = {
  monsters: Array.from({ length: 12 }, () => "cuc-bong-ma-quai"),
  spells: Array.from({ length: 12 }, () => "mua-ma-thuat"),
};
function fielded() {
  let duel = summon(draw(createDuel(COTTON), "spell"), 0, 0);
  duel = endTurn(duel);
  duel = summon(draw(duel, "spell"), 0, 0);
  return endTurn(duel);
}
__name(fielded, "fielded");
test("fairy attack bless adds 2 attack when the ally strikes", () => {
  const base = fielded();
  const attacker = base.players[0].field[0];
  const defender = base.players[1].field[0];
  assert.ok(attacker && defender);
  const duel = {
    ...base,
    players: [
      {
        ...base.players[0],
        field: [{ ...attacker, atk: 2, blessAtk: 2, hp: 5, maxHp: 5 }, null, null],
      },
      {
        ...base.players[1],
        hp: 20,
        field: [{ ...defender, atk: 0, def: 0, hp: 10, maxHp: 10 }, null, null],
      },
    ],
  };
  const melee = passResponse(attackMonster(duel, attacker.uid, defender.uid));
  assert.equal(melee.players[1].field[0]?.hp, 6);
  const face = passResponse(attackFace(duel, attacker.uid));
  assert.equal(face.players[1].hp, 16);
  assert.equal(face.players[0].field[0]?.blessAtk ?? 0, 0);
});
test("stone soldier walls for an ally and only blocks twice", () => {
  const deck = {
    monsters: [
      "linh-chien-da-khong-lo",
      "linh-chien-da-khong-lo",
      "linh-chien-da-khong-lo",
      "linh-chien-da-khong-lo",
    ],
    spells: ["mua-ma-thuat", "mua-ma-thuat"],
  };
  const born = summon(createDuel(deck, "test"), 0, 0);
  assert.equal(born.players[0].field[0]?.blocksLeft, 2);
  const base = fielded();
  const foe = base.players[0].field[0];
  const ally = base.players[1].field[0];
  assert.ok(foe && ally);
  const soldier = {
    ...ally,
    uid: "1-wall",
    cardId: "linh-chien-da-khong-lo",
    atk: 1,
    def: 2,
    mdef: 2,
    hp: 8,
    maxHp: 8,
    blocksLeft: 2,
    dim: false,
  };
  const duel = {
    ...base,
    players: [
      { ...base.players[0], field: [{ ...foe, atk: 3, def: 0, hp: 6, maxHp: 6 }, null, null] },
      {
        ...base.players[1],
        orb: 3,
        field: [{ ...ally, atk: 0, def: 0, hp: 4, maxHp: 4 }, soldier, null],
      },
    ],
  };
  const swung = attackMonster(duel, foe.uid, ally.uid);
  const walled = wallAlly(swung, soldier.uid);
  assert.equal(walled.pending?.kind === "melee" ? walled.pending.defender : "", soldier.uid);
  const hit = passResponse(walled);
  assert.equal(hit.players[1].field[0]?.hp, 4);
  const guard = hit.players[1].field.find((mon) => mon?.uid === soldier.uid);
  assert.equal(guard?.hp, 7);
  assert.equal(guard?.blocksLeft, 1);
  assert.equal(guard?.dim, false);
  const fresh = {
    ...hit,
    players: [
      {
        ...hit.players[0],
        field: hit.players[0].field.map((mon) => (mon ? { ...mon, dim: false } : mon)),
      },
      hit.players[1],
    ],
  };
  const again = passResponse(wallAlly(attackMonster(fresh, foe.uid, ally.uid), soldier.uid));
  assert.equal(again.players[1].field[0]?.hp, 4);
  const spent = again.players[1].field.find((mon) => mon?.uid === soldier.uid);
  assert.equal(spent?.hp, 6);
  assert.equal(spent?.dim, true);
  const caster = { ...foe, cardId: "ma-dao-si", atk: 2, dim: false };
  const aimed = {
    ...duel,
    players: [{ ...duel.players[0], orb: 3, field: [caster, null, null] }, duel.players[1]],
  };
  const beam = declareSkill(aimed, caster.uid, ally.uid, 0);
  const covered = wallAlly(beam, soldier.uid);
  assert.equal(covered.pending?.kind === "beam" ? covered.pending.target : "", soldier.uid);
  const shot = passResponse(covered);
  assert.equal(shot.players[1].field[0]?.hp, 4);
  const stone = shot.players[1].field.find((mon) => mon?.uid === soldier.uid);
  assert.ok(stone && stone.hp < 8);
  assert.equal(stone?.blocksLeft, 1);
});
test("doomsday thunder deals 2 plus stars as true damage to every enemy", () => {
  const base = fielded();
  const you = base.players[0];
  const foe = base.players[1];
  const ally = you.field[0];
  const enemy = foe.field[0];
  assert.ok(ally && enemy);
  const stars = 3;
  const duel = {
    ...base,
    players: [
      {
        ...you,
        stars,
        orb: 3,
        hand: ["sam-set-tan-the"],
        tolls: [false],
        field: [{ ...ally, hp: 10, maxHp: 10, def: 5, mdef: 5 }, null, null],
      },
      { ...foe, field: [{ ...enemy, hp: 4, maxHp: 4, def: 5, mdef: 5 }, null, null] },
    ],
  };
  const hit = passResponse(castSpell(duel, 0, null));
  assert.equal(hit.players[0].field[0]?.hp, 10);
  assert.equal(hit.players[0].orb, 0);
  assert.equal(hit.players[1].field[0], null);
  assert.match(hit.live, /gây 5 sát thương chuẩn/);
});
test("multi-target skill notice lists each monster under the skill name", () => {
  const base = fielded();
  const caster = base.players[0].field[0];
  const first = base.players[1].field[0];
  assert.ok(caster && first);
  const second = { ...first, uid: "1-other", hp: 6, maxHp: 6 };
  const duel = {
    ...base,
    players: [
      {
        ...base.players[0],
        field: [{ ...caster, cardId: "loi-nguyen-cua-rong", dim: false }, null, null],
      },
      { ...base.players[1], field: [{ ...first, hp: 6, maxHp: 6, def: 5, mdef: 5 }, second, null] },
    ],
  };
  const hit = useSkill(duel, caster.uid, first.uid, 0);
  assert.match(
    hit.live,
    /Địa ngục lửa\n- gây 2 sát thương chuẩn lên .+\.\n- gây 2 sát thương chuẩn lên .+\./,
  );
});
test("turn 1 gives both players a second gem", () => {
  const duel = createDuel();
  assert.equal(duel.players[0].orb, 2);
  assert.equal(duel.players[1].orb, 2);
  assert.equal(duel.players[0].flask, 0);
  assert.equal(duel.players[0].stars, 0);
  assert.equal(duel.players[0].reserve.length, 2);
  assert.equal(duel.players[1].reserve.length, 2);
  assert.equal(duel.players[0].hand.length, 1);
  assert.equal(duel.players[1].hand.length, 1);
  assert.equal(duel.players[0].draws, 0);
  assert.equal(duel.players[0].hp, 20);
});
test("opening spell is free and both sides can still draw", () => {
  const duel = createDuel();
  assert.equal(duel.players[0].stars, 0);
  assert.equal(duel.players[0].starGems, 0);
  assert.equal(duel.players[0].orb, 2);
  assert.equal(duel.players[1].hand.length, 1);
  const drawn = draw(duel, "monster");
  assert.equal(drawn.players[0].hand.length, 1);
  assert.equal(drawn.players[0].reserve.length, 3);
  assert.equal(drawn.players[0].draws, 1);
  assert.equal(drawn.players[0].stars, 1);
  const bare = createDuel({ monsters: ["ong-khong-lo", "ong-khong-lo", "ong-khong-lo", "ong-khong-lo"], spells: [] }, "ai");
  assert.equal(bare.players[0].hand.length, 0);
  assert.equal(bare.players[1].hand.length, 0);
  const sea = createDuel(
    { monsters: ["ong-khong-lo", "ong-khong-lo", "ong-khong-lo", "ong-khong-lo"], spells: ["bien-sau", "mua-ma-thuat"] },
    "ai",
  );
  assert.equal(sea.players[0].env, "bien-sau");
  assert.equal(sea.players[0].hand.length, 1);
  assert.equal(sea.players[0].hand[0], "mua-ma-thuat");
  assert.equal(sea.players[0].spellDeck.length, 0);
});
test("later stars cost 6 then 10 mana", () => {
  const deck = {
    monsters: ["ong-khong-lo", "ong-khong-lo", "ong-khong-lo", "ong-khong-lo"],
    spells: Array.from({ length: 30 }, () => "mua-ma-thuat"),
  };
  const spend = (gems: number) => {
    let next = createDuel(deck, "ai");
    for (let i = 0; i < gems; i += 1) {
      next = {
        ...next,
        players: [{ ...next.players[0], draws: 0, orb: Math.max(next.players[0].orb, 1) }, next.players[1]],
      };
      const drawn = draw(next, "spell");
      assert.equal(drawn.players[0].draws, 1);
      next = drawn;
    }
    return next.players[0];
  };
  assert.equal(spend(1).stars, 1);
  assert.equal(spend(1).starGems, 0);
  assert.equal(spend(4).stars, 2);
  assert.equal(spend(4).starGems, 0);
  assert.equal(spend(9).stars, 2);
  assert.equal(spend(9).starGems, 5);
  assert.equal(spend(10).stars, 3);
  assert.equal(spend(10).starGems, 0);
  assert.equal(spend(19).stars, 3);
  assert.equal(spend(19).starGems, 9);
  assert.equal(spend(20).stars, 4);
  assert.equal(spend(20).starGems, 0);
});
test("the mana flask holds at most 1", () => {
  const duel = createDuel();
  const full = {
    ...duel,
    opening: false,
    players: [
      { ...duel.players[0], orb: 3, flask: 1 },
      { ...duel.players[1], orb: 2, flask: 5 },
    ],
  };
  const next = endTurn(full);
  assert.equal(next.players[0].orb, 3);
  assert.equal(next.players[0].flask, 1);
  assert.equal(next.players[1].orb, 3);
  assert.equal(next.players[1].flask, 1);
});
test("drawing a spell spends a gem and raises the first star", () => {
  const duel = draw(createDuel(), "spell");
  const you = duel.players[0];
  assert.equal(you.orb, 1);
  assert.equal(you.stars, 1);
  assert.equal(you.starGems, 0);
  assert.equal(you.hand.length, 2);
  assert.equal(you.draws, 1);
});
test("fusion spends the hand card and the field card without using the normal summon", () => {
  FUSIONS.push({ materials: ["cuc-bong-ma-quai", "rong-con"], result: "rong-ngan-tuoi" });
  try {
    let duel = createDuel({ monsters: ["phu-thuy-thoi-gian"], spells: ["mua-ma-thuat"] }, "test");
    duel = testGrant(duel, 0, "rong-con", true);
    duel = testGrant(duel, 0, "kiem-si-lua-thieng", true);
    duel = testGrant(duel, 0, "cuc-bong-ma-quai", false);
    const host = duel.players[0].field[0];
    const reserveIndex = duel.players[0].reserve.findIndex(
      (held) => held.id === "cuc-bong-ma-quai",
    );
    assert.ok(host);
    assert.ok(reserveIndex >= 0);
    const summons = duel.players[0].summons;
    const blocked = fuse(duel, reserveIndex, host.uid, 1);
    assert.equal(blocked.players[0].field[1]?.cardId, "kiem-si-lua-thieng");
    assert.match(blocked.live, /Ô này đã có quái/);
    const next = fuse(duel, reserveIndex, host.uid, 0);
    assert.equal(next.players[0].field[0]?.cardId, "rong-ngan-tuoi");
    assert.equal(
      next.players[0].reserve.some((held) => held.id === "cuc-bong-ma-quai"),
      false,
    );
    assert.equal(next.players[0].summons, summons);
    assert.match(next.live, /Hợp nhất Cục bông ma quái và Rồng con trở thành Rồng ngàn tuổi/);
    assert.ok(next.players[0].spent?.includes("cuc-bong-ma-quai"));
    assert.ok(next.players[0].spent?.includes("rong-con"));
    const moved = fuse(duel, reserveIndex, host.uid, 2);
    assert.equal(moved.players[0].field[2]?.cardId, "rong-ngan-tuoi");
    assert.equal(moved.players[0].field[0], null);
  } finally {
    FUSIONS.pop();
  }
});
test("dragon rider fusion keeps four true damage and splashes the other enemy", () => {
  assert.equal(findFusion("loi-nguyen-cua-rong", "ky-si-bong-toi")?.result, "ky-si-cuoi-rong");
  let duel = createDuel({ monsters: ["phu-thuy-thoi-gian"], spells: ["mua-ma-thuat"] }, "test");
  duel = testGrant(duel, 0, "ky-si-cuoi-rong", true);
  duel = testGrant(duel, 1, "cuc-bong-ma-quai", true);
  duel = testGrant(duel, 1, "cuc-bong-ma-quai", true);
  const rider = duel.players[0].field[0];
  const first = duel.players[1].field[0];
  const second = duel.players[1].field[1];
  assert.ok(rider && first && second);
  const ready = {
    ...duel,
    players: [
      { ...duel.players[0], field: [{ ...rider, atk: 6, hp: 30, maxHp: 30 }, null, null] },
      {
        ...duel.players[1],
        field: [
          { ...first, atk: 0, def: 0, hp: 20, maxHp: 20 },
          { ...second, atk: 0, def: 0, hp: 20, maxHp: 20 },
          null,
        ],
      },
    ],
  };
  const hit = passResponse(attackMonster(ready, rider.uid, first.uid));
  assert.equal(hit.players[1].field[0]?.hp, 14);
  assert.equal(hit.players[1].field[1]?.hp, 18);
  assert.deepEqual(hit.skill?.vols, [4, 2, 2]);
  assert.match(
    hit.live,
    /Kỵ sĩ cưỡi rồng dùng\n- Mũi thương bị nguyền rủa lên Cục bông ma quái gây 2 sát thương vật lý, 4 sát thương chuẩn\.\n- Lửa địa ngục gây 2 sát thương chuẩn lên Cục bông ma quái/,
  );
  const walled = {
    ...ready,
    players: [
      ready.players[0],
      {
        ...ready.players[1],
        field: [
          { ...first, atk: 0, def: 3, hp: 20, maxHp: 20 },
          { ...second, atk: 0, def: 0, hp: 20, maxHp: 20 },
          null,
        ],
      },
    ],
  };
  const thick = passResponse(attackMonster(walled, rider.uid, first.uid));
  assert.equal(thick.players[1].field[0]?.hp, 16);
  const heavy = {
    ...ready,
    players: [
      { ...ready.players[0], field: [{ ...rider, atk: 7, hp: 30, maxHp: 30 }, null, null] },
      ready.players[1],
    ],
  };
  const seven = passResponse(attackMonster(heavy, rider.uid, first.uid));
  assert.equal(seven.players[1].field[0]?.hp, 13);
  assert.deepEqual(seven.skill?.vols, [5, 2, 2]);
  const face = passResponse(attackFace(ready, rider.uid));
  assert.equal(face.players[1].hp, ready.players[1].hp - 6);
  const back = passResponse(
    attackMonster(
      {
        ...ready,
        turn: 1,
        players: [
          { ...ready.players[0], field: [{ ...rider, atk: 6, hp: 30, maxHp: 30 }, null, null] },
          {
            ...ready.players[1],
            field: [
              { ...first, atk: 0, def: 0, hp: 20, maxHp: 20 },
              { ...second, atk: 0, def: 0, hp: 20, maxHp: 20 },
              null,
            ],
          },
        ],
      },
      first.uid,
      rider.uid,
    ),
  );
  assert.equal(back.players[1].field[0]?.hp, 14);
  assert.equal(back.players[1].field[1]?.hp, 18);
  assert.equal(back.players[0].field[0]?.hp, 30);
  assert.deepEqual(back.skill?.vols, [4, 2, 2]);
  assert.equal(back.skill?.hits[0], first.uid);
  assert.equal(back.skill?.hits[1], first.uid);
});
test("a one-star monster can be summoned after the first star", () => {
  const summoned = summon(draw(createDuel(COTTON), "spell"), 0, 0);
  assert.equal(summoned.players[0].field[0]?.cardId, "cuc-bong-ma-quai");
  assert.equal(summoned.players[0].reserve.length, 1);
  assert.equal(summoned.players[0].stars, 1);
});
test("time witch summon does not spend the normal summon", () => {
  let duel = createDuel(
    {
      monsters: ["phu-thuy-thoi-gian", "cuc-bong-ma-quai"],
      spells: ["mua-ma-thuat", "mua-ma-thuat"],
    },
    "test",
  );
  duel = {
    ...duel,
    players: [
      {
        ...duel.players[0],
        stars: 4,
        orb: 3,
        reserve: [
          { id: "cuc-bong-ma-quai", hp: 1, maxHp: 1 },
          { id: "phu-thuy-thoi-gian", hp: 1, maxHp: 1 },
          { id: "phu-thuy-thoi-gian", hp: 1, maxHp: 1 },
        ],
      },
      duel.players[1],
    ],
  };
  const normal = summon(duel, 0, 0);
  assert.equal(normal.players[0].summons, 1);
  const extra = summon(normal, 0, 1);
  assert.equal(extra.players[0].field[1]?.cardId, "phu-thuy-thoi-gian");
  assert.equal(extra.players[0].summons, 1);
  const blocked = summon(extra, 0, 2);
  assert.equal(blocked.players[0].field[2], null);
  assert.match(blocked.live, /đã triệu hồi trong lượt này/);
  const first = summon(duel, 1, 0);
  assert.equal(first.players[0].field[0]?.cardId, "phu-thuy-thoi-gian");
  assert.equal(first.players[0].summons, 0);
  const follow = summon(first, 0, 1);
  assert.equal(follow.players[0].field[1]?.cardId, "cuc-bong-ma-quai");
  assert.equal(follow.players[0].summons, 1);
});
test("melee subtracts defense on both sides", () => {
  const duel = fielded();
  const attacker = duel.players[0].field[0];
  const defender = duel.players[1].field[0];
  assert.ok(attacker && defender);
  const next = passResponse(passResponse(attackMonster(duel, attacker.uid, defender.uid)));
  assert.equal(next.players[0].field[0], null);
  assert.equal(next.players[1].field[0], null);
});
test("K\u1EBB \u0111\xE0o m\u1ED9 copies a card that left and the copy costs one extra gem", () => {
  const deck = {
    monsters: ["ong-khong-lo", "ong-khong-lo", "ong-khong-lo", "ong-khong-lo"],
    spells: ["ke-dao-mo", "mua-ma-thuat", "mua-ma-thuat", "mua-ma-thuat"],
  };
  const duel = createDuel(deck, "test");
  const armed = {
    ...duel,
    players: [
      { ...duel.players[0], hand: ["ke-dao-mo"], tolls: [false] },
      { ...duel.players[1], hand: [], tolls: [], spent: ["mua-ma-thuat", "ong-khong-lo"] },
    ],
  };
  const spellDug = digGrave(armed, 0, "mua-ma-thuat");
  assert.equal(spellDug.log.length, armed.log.length);
  assert.equal(spellDug.live, armed.live);
  assert.equal(spellDug.players[0].hand.includes("ke-dao-mo"), false);
  assert.equal(spellDug.players[0].hand.at(-1), "mua-ma-thuat");
  assert.equal(spellDug.players[0].tolls?.at(-1), true);
  assert.equal(spellDug.players[1].hand.includes("mua-ma-thuat"), false);
  const cast = castSpell(spellDug, spellDug.players[0].hand.lastIndexOf("mua-ma-thuat"));
  assert.equal(cast.players[0].orb, spellDug.players[0].orb - 1);
  const monDug = digGrave(armed, 0, "ong-khong-lo");
  const pile = monDug.players[0].reserve.at(-1);
  assert.equal(pile?.id, "ong-khong-lo");
  assert.equal(pile?.toll, true);
  const summoned = summon(monDug, monDug.players[0].reserve.length - 1, 0);
  assert.equal(summoned.players[0].orb, monDug.players[0].orb - 1);
  assert.equal(summoned.players[0].field[0]?.cardId, "ong-khong-lo");
  const missed = digGrave(armed, 0, "khong-co");
  assert.equal(missed.players[0].hand[0], "ke-dao-mo");
});
test("spider bombs land five true damage for one gem", () => {
  const deck = {
    monsters: [
      "may-nem-bom-hinh-nhen",
      "may-nem-bom-hinh-nhen",
      "may-nem-bom-hinh-nhen",
      "may-nem-bom-hinh-nhen",
    ],
    spells: ["mua-ma-thuat", "mua-ma-thuat"],
  };
  let duel = createDuel(deck, "test");
  duel = summon(duel, 0, 0);
  duel = endTurn(duel);
  duel = summon(duel, 0, 0);
  duel = endTurn(duel);
  const foe = duel.players[1].field[0];
  const you = duel.players[0].field[0];
  assert.ok(foe && you);
  duel = {
    ...duel,
    players: [
      duel.players[0],
      {
        ...duel.players[1],
        field: duel.players[1].field.map((mon) =>
          mon?.uid === foe.uid ? { ...mon, hp: 100, maxHp: 100 } : mon,
        ),
      },
    ],
  };
  const aimed = declareSkill(duel, you.uid, foe.uid, 0);
  assert.equal(aimed.pending?.kind, "beam");
  const done = passResponse(aimed);
  const left = done.players[1].field[0]?.hp ?? 0;
  assert.equal(100 - left + (20 - done.players[1].hp), 5);
  assert.equal(done.players[0].orb, duel.players[0].orb - 1);
  assert.equal(done.players[0].field[0]?.dim, true);
  const hits = done.skill?.hits ?? [];
  const vols = done.skill?.vols ?? [];
  assert.equal(hits.length, 5);
  assert.deepEqual(vols, [1, 1, 1, 1, 1]);
  for (const id of hits) assert.ok(id === foe.uid || id === "face:1");
  if (done.players[1].hp < 20) assert.ok(hits.includes("face:1"));
  if (left < 100) assert.ok(hits.includes(foe.uid));
});
test("spear dragon marks the monsters it hits and not the player", () => {
  const deck = {
    monsters: ["thuong-quan-long", "thuong-quan-long", "thuong-quan-long", "thuong-quan-long"],
    spells: ["mua-ma-thuat", "mua-ma-thuat"],
  };
  const foes = {
    monsters: ["khong-lo-mot-mat", "khong-lo-mot-mat", "khong-lo-mot-mat", "khong-lo-mot-mat"],
    spells: ["mua-ma-thuat", "mua-ma-thuat"],
  };
  let duel = createDuel(deck, "test", foes);
  duel = summon(duel, 0, 0);
  duel = endTurn(duel);
  duel = summon(duel, 0, 0);
  duel = endTurn(duel);
  const foe = duel.players[1].field[0];
  const you = duel.players[0].field[0];
  assert.ok(foe && you);
  duel = {
    ...duel,
    players: [
      duel.players[0],
      {
        ...duel.players[1],
        field: duel.players[1].field.map((mon) =>
          mon?.uid === foe.uid ? { ...mon, def: 100, mdef: 100 } : mon,
        ),
      },
    ],
  };
  const parked = duel.players[1].hp;
  const body = duel.players[1].field[0]?.hp ?? 0;
  let marked = false;
  for (let turn = 0; turn < 40 && !marked; turn += 1) {
    const spinning = passResponse(declareSkill(structuredClone(duel), you.uid, null, 0));
    assert.equal(spinning.reel?.kind, "gun");
    assert.equal(spinning.reel?.phase, "spin");
    assert.equal(spinning.reel?.faces?.length, 3);
    const done = settleReel(spinning);
    const hits = done.skill?.hits ?? [];
    assert.equal(done.players[1].hp, parked);
    if (hits.length === 0 || (done.players[1].field[0]?.hp ?? 0) !== body) continue;
    marked = true;
    for (const id of hits) assert.equal(id, foe.uid);
  }
  assert.equal(marked, true);
});
test("spear reel shows the barrels and the old shots still fire", () => {
  const deck = {
    monsters: ["thuong-quan-long", "thuong-quan-long", "thuong-quan-long", "thuong-quan-long"],
    spells: ["mua-ma-thuat", "mua-ma-thuat"],
  };
  const foes = {
    monsters: ["khong-lo-mot-mat", "khong-lo-mot-mat", "khong-lo-mot-mat", "khong-lo-mot-mat"],
    spells: ["mua-ma-thuat", "mua-ma-thuat"],
  };
  let duel = createDuel(deck, "test", foes);
  duel = summon(duel, 0, 0);
  duel = endTurn(duel);
  duel = summon(duel, 0, 0);
  duel = endTurn(duel);
  const foe = duel.players[1].field[0];
  const you = duel.players[0].field[0];
  assert.ok(foe && you);
  const waiting = passResponse(declareSkill(duel, you.uid, null, 0));
  const order = [...(waiting.reel?.order ?? [])].sort();
  assert.deepEqual(order, ["phys", "spell", "tru"]);
  const spun = {
    ...waiting,
    reel: { ...waiting.reel, phase: "spin", faces: ["phys", "blank", "tru"] },
  };
  const done = settleReel(spun);
  assert.equal(done.reel, null);
  assert.match(done.live, /sát thương vật lý/);
  assert.match(done.live, /sát thương chuẩn/);
  assert.doesNotMatch(done.live, /sát thương phép/);
  assert.equal(done.players[0].field[0]?.dim, true);
  assert.equal(done.players[0].orb, duel.players[0].orb - 1);
  assert.equal(done.players[1].hp, duel.players[1].hp);
  const missed = settleReel({
    ...passResponse(declareSkill(structuredClone(duel), you.uid, null, 0)),
    reel: { ...waiting.reel, phase: "spin", faces: ["blank", "blank", "blank"] },
  });
  assert.equal(missed.players[1].field[0]?.hp, foe.hp);
  assert.equal(missed.players[0].field[0]?.dim, true);
  assert.equal(missed.players[1].hp, duel.players[1].hp);
});
test("angry gambler uses the spell burst", () => {
  assert.equal(skillLook("may-quay-thuong", 1), "spell");
  assert.equal(skillLook("may-quay-thuong", 0), null);
});
test("time machine restores the ally before the hit lands", () => {
  const deck = {
    monsters: ["ong-khong-lo", "ong-khong-lo", "ong-khong-lo", "ong-khong-lo"],
    spells: ["co-may-thoi-gian", "co-may-thoi-gian"],
  };
  let duel = createDuel(deck, "test");
  duel = summon(duel, 0, 0);
  const born = duel.players[0].field[0];
  assert.ok(born);
  duel = endTurn(duel);
  duel = summon(duel, 0, 0);
  const foe = duel.players[1].field[0];
  assert.ok(foe);
  duel = {
    ...duel,
    players: [
      {
        ...duel.players[0],
        hand: ["co-may-thoi-gian"],
        tolls: [false],
        field: duel.players[0].field.map((mon) =>
          mon?.uid === born.uid ? { ...mon, hp: 1 } : mon,
        ),
      },
      duel.players[1],
    ],
  };
  const attacked = attackMonster(duel, foe.uid, born.uid);
  assert.equal(attacked.step, "respond");
  const rewound = castSpell(attacked, 0, born.uid);
  assert.equal(rewound.players[0].field[0]?.hp, born.hp);
  assert.equal(rewound.pending?.kind, "melee");
  assert.equal(rewound.players[0].hand.includes("co-may-thoi-gian"), false);
});
test("time machine rewinds to the start of three shared turns ago", () => {
  const deck = {
    monsters: ["ong-khong-lo", "ong-khong-lo", "ong-khong-lo", "ong-khong-lo"],
    spells: ["co-may-thoi-gian", "co-may-thoi-gian"],
  };
  let duel = createDuel(deck, "test");
  duel = summon(duel, 0, 0);
  const born = duel.players[0].field[0];
  assert.ok(born);
  const mark = __name((hp) => {
    duel = {
      ...duel,
      players: [
        {
          ...duel.players[0],
          field: duel.players[0].field.map((mon) => (mon?.uid === born.uid ? { ...mon, hp } : mon)),
        },
        duel.players[1],
      ],
    };
  }, "mark");
  duel = endTurn(duel);
  duel = summon(duel, 0, 0);
  duel = endTurn(duel);
  mark(6);
  duel = endTurn(duel);
  mark(5);
  duel = endTurn(duel);
  mark(4);
  duel = endTurn(duel);
  mark(3);
  duel = endTurn(duel);
  mark(2);
  duel = endTurn(duel);
  mark(1);
  const foe = duel.players[1].field[0];
  assert.ok(foe);
  duel = {
    ...duel,
    players: [{ ...duel.players[0], hand: ["co-may-thoi-gian"], tolls: [false] }, duel.players[1]],
  };
  const attacked = attackMonster(duel, foe.uid, born.uid);
  assert.equal(attacked.step, "respond");
  assert.equal(castSpell(attacked, 0, null).players[0].field[0]?.hp, 1);
  const rewound = castSpell(attacked, 0, born.uid);
  assert.equal(rewound.players[0].field[0]?.hp, 5);
  assert.match(rewound.live, /3 lượt chung trước/);
});
test("time machine uses the summon moment when the ally was summoned after that mark", () => {
  const deck = {
    monsters: ["ong-khong-lo", "ong-khong-lo", "ong-khong-lo", "ong-khong-lo"],
    spells: ["co-may-thoi-gian", "co-may-thoi-gian"],
  };
  let duel = createDuel(deck, "test");
  duel = summon(duel, 0, 0);
  duel = endTurn(duel);
  duel = summon(duel, 0, 0);
  for (let i = 0; i < 5; i += 1) duel = endTurn(duel);
  if (duel.turn !== 0) duel = endTurn(duel);
  duel = summon(duel, 0, 1);
  const late = duel.players[0].field[1];
  assert.ok(late);
  const bornHp = late.hp;
  const mark = __name((hp) => {
    duel = {
      ...duel,
      players: [
        {
          ...duel.players[0],
          field: duel.players[0].field.map((mon) => (mon?.uid === late.uid ? { ...mon, hp } : mon)),
        },
        duel.players[1],
      ],
    };
  }, "mark");
  mark(4);
  duel = endTurn(duel);
  mark(2);
  duel = endTurn(duel);
  mark(1);
  duel = endTurn(duel);
  const foe = duel.players[1].field[0];
  assert.ok(foe);
  duel = {
    ...duel,
    players: [{ ...duel.players[0], hand: ["co-may-thoi-gian"], tolls: [false] }, duel.players[1]],
  };
  const attacked = attackMonster(duel, foe.uid, late.uid);
  const rewound = castSpell(attacked, 0, late.uid);
  assert.equal(rewound.players[0].field.find((mon) => mon?.uid === late.uid)?.hp, bornHp);
  assert.match(rewound.live, /lúc vừa triệu hồi/);
});
test("mechanical armor buffs first and reflects the original skill only when attack is higher", () => {
  const deck = {
    monsters: ["phu-thuy-thoi-gian", "mat-do-tan-pha"],
    spells: ["giap-co-khi", "giap-co-khi"],
  };
  const aim = __name(() => {
    let duel = createDuel(deck, "test");
    const witch = duel.players[0].reserve.findIndex((mon) => mon.id === "phu-thuy-thoi-gian");
    duel = summon(duel, witch, 0);
    duel = endTurn(duel);
    const redAt = duel.players[1].reserve.findIndex((mon) => mon.id === "mat-do-tan-pha");
    duel = summon(duel, redAt, 0);
    const ally2 = duel.players[0].field[0];
    const caster2 = duel.players[1].field[0];
    assert.ok(ally2 && caster2);
    return { duel, ally: ally2, caster: caster2 };
  }, "aim");
  const weak = aim();
  const armed = {
    ...weak.duel,
    players: [
      { ...weak.duel.players[0], hand: ["giap-co-khi"], tolls: [false] },
      weak.duel.players[1],
    ],
  };
  const shot = declareSkill(armed, weak.caster.uid, weak.ally.uid, 0);
  const held = castSpell(shot, 0, weak.ally.uid);
  const buffed = held.players[0].field[0];
  assert.equal(buffed?.atk, weak.ally.atk + 2);
  assert.equal(buffed?.mdef, weak.ally.mdef + 2);
  assert.equal(held.pending?.kind, "beam");
  assert.equal(held.pending && "back" in held.pending ? held.pending.back : false, false);
  const strong = aim();
  const tough = {
    ...strong.duel,
    players: [
      {
        ...strong.duel.players[0],
        hand: ["giap-co-khi"],
        tolls: [false],
        field: strong.duel.players[0].field.map((mon) => (mon ? { ...mon, atk: 10 } : mon)),
      },
      strong.duel.players[1],
    ],
  };
  const ally = tough.players[0].field[0];
  const caster = tough.players[1].field[0];
  assert.ok(ally && caster);
  const bounced = castSpell(declareSkill(tough, caster.uid, ally.uid, 0), 0, ally.uid);
  assert.equal(bounced.players[0].field[0]?.atk, 12);
  assert.equal(bounced.pending?.kind, "beam");
  if (bounced.pending?.kind === "beam") {
    assert.equal(bounced.pending.back, true);
    assert.equal(bounced.pending.target, caster.uid);
  }
});
test("one-eyed giant does not grow after a melee clash", () => {
  const deck = {
    monsters: ["khong-lo-mot-mat", "phu-thuy-thoi-gian"],
    spells: ["mua-ma-thuat", "mua-ma-thuat"],
  };
  let duel = createDuel(deck, "test");
  const giantAt = duel.players[0].reserve.findIndex((mon) => mon.id === "khong-lo-mot-mat");
  duel = summon(duel, giantAt, 0);
  const giant = duel.players[0].field[0];
  assert.ok(giant);
  duel = endTurn(duel);
  const witchAt = duel.players[1].reserve.findIndex((mon) => mon.id === "phu-thuy-thoi-gian");
  duel = summon(duel, witchAt, 0);
  const witch = duel.players[1].field[0];
  assert.ok(witch);
  const struck = passResponse(attackMonster(duel, witch.uid, giant.uid));
  const grown = struck.players[0].field[0];
  assert.equal(grown?.hp, giant.hp);
  assert.equal(grown?.maxHp, giant.maxHp || giant.hp);
});
test("magic hats cover empty slots and drop when one real monster is left", () => {
  const deck = {
    monsters: ["khong-lo-mot-mat", "phu-thuy-thoi-gian"],
    spells: ["mu-ma-phap", "mua-ma-thuat"],
  };
  let duel = createDuel(deck, "test");
  const bare = castSpell(
    {
      ...duel,
      players: [{ ...duel.players[0], hand: ["mu-ma-phap"], tolls: [false] }, duel.players[1]],
    },
    0,
  );
  assert.match(bare.live, /Cần có quái/);
  const at = duel.players[0].reserve.findIndex((mon) => mon.id === "khong-lo-mot-mat");
  duel = summon(duel, at, 0);
  duel = {
    ...duel,
    players: [{ ...duel.players[0], hand: ["mu-ma-phap"], tolls: [false] }, duel.players[1]],
  };
  const cast = passResponse(castSpell(duel, 0));
  assert.equal(cast.players[0].hats, true);
  assert.equal(cast.players[0].field.filter((mon) => mon?.cardId === "mu").length, 2);
  let foe = endTurn(cast);
  const witchAt = foe.players[1].reserve.findIndex((mon) => mon.id === "phu-thuy-thoi-gian");
  foe = summon(foe, witchAt, 0);
  const witch = foe.players[1].field[0];
  assert.ok(witch);
  const first = foe.players[0].field.find((mon) => mon?.cardId === "mu");
  assert.ok(first);
  let hit = passResponse(attackMonster(foe, witch.uid, first.uid));
  assert.equal(hit.players[0].hats, true);
  assert.equal(hit.players[0].field.filter((mon) => mon?.cardId === "mu").length, 1);
  const last = hit.players[0].field.find((mon) => mon?.cardId === "mu");
  assert.ok(last);
  hit = endTurn(endTurn(hit));
  const witchAgain = hit.players[1].field.find((mon) => mon?.cardId === "phu-thuy-thoi-gian");
  const lastHat = hit.players[0].field.find((mon) => mon?.cardId === "mu");
  assert.equal(hit.turn, 1);
  assert.ok(witchAgain && lastHat);
  hit = passResponse(attackMonster(hit, witchAgain.uid, lastHat.uid));
  assert.equal(
    hit.players[0].field.some((mon) => mon?.cardId === "mu"),
    false,
  );
  assert.equal(hit.players[0].hats, false);
  assert.equal(hit.players[0].field.filter((mon) => mon?.cardId === "khong-lo-mot-mat").length, 1);
});
test("virus corrodes one random monster, updates reserve hp, and hides deck names", () => {
  const deck = {
    monsters: ["ma-dao-si", "ma-dao-si", "ma-dao-si", "ma-dao-si"],
    spells: ["virus-an-mon", "virus-an-mon"],
  };
  const mage = __name(() => ({ id: "ma-dao-si", hp: 5, maxHp: 5 }), "mage");
  let duel = createDuel(deck, "test");
  duel = {
    ...duel,
    virus: { owner: 0 },
    players: [
      duel.players[0],
      { ...duel.players[1], monsterDeck: [], reserve: [mage(), mage()], field: [null, null, null] },
    ],
  };
  const once = endTurn(duel);
  assert.equal(once.players[1].reserve.length, 2);
  assert.equal(
    once.players[1].reserve.reduce((sum, card) => sum + card.hp, 0),
    9,
  );
  assert.match(once.live, /Ma đạo sĩ/);
  duel = {
    ...duel,
    virus: { owner: 0 },
    players: [
      duel.players[0],
      {
        ...duel.players[1],
        monsterDeck: [],
        reserve: [{ id: "ma-dao-si", hp: 1, maxHp: 5 }],
        field: [null, null, null],
      },
    ],
  };
  const dead = endTurn(duel);
  assert.equal(dead.players[1].reserve.length, 0);
  assert.match(dead.live, /tiêu diệt Ma đạo sĩ/);
  duel = {
    ...duel,
    virus: { owner: 0 },
    players: [
      duel.players[0],
      {
        ...duel.players[1],
        monsterDeck: [{ id: "ma-dao-si", hp: 1, maxHp: 5 }],
        reserve: [],
        field: [null, null, null],
      },
    ],
  };
  const hidden = endTurn(duel);
  assert.equal(hidden.players[1].monsterDeck.length, 0);
  assert.match(hidden.live, /tiêu diệt Ma đạo sĩ trong bộ bài/);
  duel = createDuel(deck, "test");
  duel = {
    ...duel,
    players: [
      { ...duel.players[0], reserve: [{ id: "ma-dao-si", hp: 3, maxHp: 5 }], summons: 0 },
      duel.players[1],
    ],
  };
  const played = summon(duel, 0, 0);
  assert.equal(played.players[0].field[0]?.hp, 3);
});
test("moth dust must aim first and the tide picks two", () => {
  const deck = {
    monsters: [
      "ngai-khong-lo",
      "ngai-nu-hoang",
      "ngai-nu-hoang",
      "ngai-nu-hoang",
      "cuc-bong-ma-quai",
      "trai-tim-hai-long",
    ],
    spells: ["mua-ma-thuat", "mua-ma-thuat"],
  };
  let duel = createDuel(deck, "test");
  duel = {
    ...duel,
    players: [
      { ...duel.players[0], reserve: [{ id: "ngai-khong-lo", hp: 6, maxHp: 6 }] },
      { ...duel.players[1], reserve: [{ id: "cuc-bong-ma-quai", hp: 1, maxHp: 1 }] },
    ],
  };
  duel = summon(duel, 0, 0);
  const moth = duel.players[0].field[0];
  assert.ok(moth);
  const missed = declareSkill(duel, moth.uid, null, 0);
  assert.match(missed.live, /Chọn một quái/);
  duel = endTurn(duel);
  duel = summon(duel, 0, 0);
  duel = endTurn(duel);
  const aimed = passResponse(declareSkill(duel, moth.uid, duel.players[1].field[0].uid, 0));
  assert.equal(aimed.players[1].field[0], null);
  let tide = createDuel(deck, "test");
  tide = {
    ...tide,
    players: [
      { ...tide.players[0], reserve: [{ id: "trai-tim-hai-long", hp: 6, maxHp: 6 }] },
      {
        ...tide.players[1],
        reserve: [
          { id: "ngai-nu-hoang", hp: 7, maxHp: 7 },
          { id: "ngai-nu-hoang", hp: 7, maxHp: 7 },
          { id: "ngai-nu-hoang", hp: 7, maxHp: 7 },
        ],
      },
    ],
  };
  tide = summon(tide, 0, 0);
  const heart = tide.players[0].field[0];
  assert.ok(heart);
  tide = endTurn(tide);
  tide = summon(tide, 0, 0);
  tide = endTurn(endTurn(tide));
  tide = summon(tide, 0, 1);
  tide = endTurn(endTurn(tide));
  tide = summon(tide, 0, 2);
  tide = endTurn(tide);
  const foes = tide.players[1].field.filter((mon) => mon);
  assert.equal(foes.length, 3);
  const swept = passResponse(declareSkill(tide, heart.uid, foes[0].uid, 2));
  assert.doesNotMatch(swept.live, /thứ hai/);
  assert.ok((swept.players[1].field[0]?.hp ?? 99) < 7);
  assert.equal(swept.players[1].field[0]?.hp, swept.players[1].field[1]?.hp);
  assert.equal(swept.players[1].field[1]?.hp, swept.players[1].field[2]?.hp);
});
test("prize reel pays pairs, triples, and the angry gambler", () => {
  let duel = createDuel(COTTON, "test");
  duel = {
    ...duel,
    players: [
      { ...duel.players[0], reserve: [{ id: "may-quay-thuong", hp: 7, maxHp: 7 }] },
      duel.players[1],
    ],
  };
  duel = summon(duel, 0, 0);
  const reel = duel.players[0].field[0];
  assert.ok(reel);
  const pair = scoreReel(duel, reel.uid, ["atk", "atk", "six"]);
  const paid = pair.players[0].field[0];
  assert.ok(paid);
  assert.equal(paid.atk, 6);
  assert.equal(paid.dim, false);
  assert.equal(paid.spun, true);
  assert.match(startReel(pair, reel.uid).live, /đã quay/);
  const triple = scoreReel(duel, reel.uid, ["atk", "atk", "atk"]);
  assert.equal(triple.players[0].field[0]?.atk, 8);
  const ward = scoreReel(duel, reel.uid, ["def", "hp", "def"]);
  assert.equal(ward.players[0].field[0]?.def, 3);
  assert.equal(ward.players[0].field[0]?.mdef, 3);
  const full = scoreReel(duel, reel.uid, ["hp", "hp", "six"]);
  assert.equal(full.players[0].field[0]?.hp, 10);
  assert.equal(full.players[0].field[0]?.maxHp, 10);
  const richer = scoreReel(duel, reel.uid, ["hp", "hp", "hp"]);
  assert.equal(richer.players[0].field[0]?.hp, 13);
  assert.equal(richer.players[0].field[0]?.maxHp, 13);
  const jackpot = scoreReel(duel, reel.uid, ["seven", "seven", "seven"]);
  assert.equal(jackpot.players[0].field[0]?.hp, 13);
  assert.equal(jackpot.players[0].field[0]?.maxHp, 13);
  assert.equal(jackpot.players[0].field[0]?.atk, 8);
  const boom = scoreReel(duel, reel.uid, ["six", "six", "six"]);
  assert.equal(boom.players[0].field[0], null);
  const miss = scoreReel(duel, reel.uid, ["atk", "def", "hp"]);
  assert.equal(miss.players[0].field[0]?.misses, 1);
  assert.equal(miss.players[0].field[0]?.atk, 4);
  const angry = passResponse(declareSkill(miss, reel.uid, null, 1));
  assert.equal(angry.players[1].hp, 16);
});
test("dragon breath hits one foe with true and spell damage", () => {
  const deck = { monsters: ["rong-con", "rong-con"], spells: ["mua-ma-thuat", "mua-ma-thuat"] };
  let duel = createDuel(deck, "test");
  duel = {
    ...duel,
    players: [
      { ...duel.players[0], reserve: [{ id: "rong-con", hp: 2, maxHp: 2 }] },
      { ...duel.players[1], reserve: [{ id: "cuc-bong-ma-quai", hp: 10, maxHp: 10 }] },
    ],
  };
  duel = summon(duel, 0, 0);
  const baby = duel.players[0].field[0];
  assert.ok(baby);
  assert.match(declareSkill(duel, baby.uid, null, 0).live, /người chơi/);
  duel = endTurn(duel);
  duel = summon(duel, 0, 0);
  duel = endTurn(duel);
  const foe = duel.players[1].field[0];
  assert.ok(foe);
  duel = {
    ...duel,
    players: [
      { ...duel.players[0], orb: 1 },
      {
        ...duel.players[1],
        field: duel.players[1].field.map((mon) =>
          mon ? { ...mon, hp: 10, maxHp: 10, mdef: 1 } : mon,
        ),
      },
    ],
  };
  const breathed = passResponse(declareSkill(duel, baby.uid, foe.uid, 0));
  assert.equal(breathed.players[1].field[0]?.hp, 8);
  assert.equal(breathed.players[0].field[0]?.dim, true);
  assert.equal(breathed.players[0].orb, 0);
  assert.match(breathed.live, /2 sát thương chuẩn và 0 sát thương phép/);
});
test("time flow evolves a young dragon into the ancient dragon", () => {
  const deck = {
    monsters: ["phu-thuy-thoi-gian", "rong-con"],
    spells: ["mua-ma-thuat", "mua-ma-thuat"],
  };
  let duel = createDuel(deck, "test");
  duel = {
    ...duel,
    players: [
      {
        ...duel.players[0],
        reserve: [
          { id: "phu-thuy-thoi-gian", hp: 1, maxHp: 1 },
          { id: "rong-con", hp: 1, maxHp: 2 },
        ],
      },
      {
        ...duel.players[1],
        reserve: [
          { id: "rong-con", hp: 2, maxHp: 2 },
          { id: "cuc-bong-ma-quai", hp: 1, maxHp: 1 },
        ],
      },
    ],
  };
  duel = summon(duel, 0, 0);
  duel = { ...duel, players: [{ ...duel.players[0], summons: 0, stars: 1 }, duel.players[1]] };
  duel = summon(duel, 0, 1);
  const witch = duel.players[0].field[0];
  assert.ok(witch);
  duel = endTurn(duel);
  duel = summon(duel, 0, 0);
  duel = { ...duel, players: [duel.players[0], { ...duel.players[1], summons: 0, stars: 1 }] };
  duel = summon(duel, 0, 1);
  duel = endTurn(duel);
  const enemy = duel.players[1].field[0];
  assert.ok(enemy);
  duel = {
    ...duel,
    players: [
      {
        ...duel.players[0],
        orb: 2,
        stars: 3,
        field: duel.players[0].field.map((mon) =>
          mon?.cardId === "rong-con" ? { ...mon, hp: 1, maxHp: 2 } : mon,
        ),
      },
      duel.players[1],
    ],
  };
  const aged = passResponse(declareSkill(duel, witch.uid, enemy.uid, 0));
  assert.match(aged.live, /bất tử/);
  const swept = useSkill(duel, witch.uid, null, 2, true, "hit");
  const ally = swept.players[0].field.find((mon) => mon?.cardId === "rong-ngan-tuoi");
  const grown = swept.players[1].field.find((mon) => mon?.cardId === "rong-ngan-tuoi");
  assert.ok(ally);
  assert.equal(ally.atk, 7);
  assert.equal(ally.hp, 8);
  assert.equal(ally.maxHp, 9);
  assert.ok(grown);
  assert.equal(grown.hp, 9);
  assert.equal(
    swept.players[1].field.some((mon) => mon?.cardId === "cuc-bong-ma-quai"),
    false,
  );
  assert.match(swept.live, /Dòng chảy thời gian quét cả sân/);
  assert.match(swept.live, /Lão hoá tiêu diệt Cục bông ma quái/);
  assert.match(swept.live, /Lão hoá tiến hoá Rồng con thành Rồng ngàn tuổi/);
});
test("empowered aging turns a young dragon into the ancient dragon", () => {
  let duel = createDuel({ monsters: ["phu-thuy-thoi-gian"], spells: ["mua-ma-thuat"] }, "test");
  duel = testGrant(duel, 0, "phu-thuy-thoi-gian", true);
  duel = testGrant(duel, 0, "rong-con", true);
  duel = testGrant(duel, 1, "rong-con", true);
  const witch = duel.players[0].field[0];
  const ally = duel.players[0].field[1];
  const foe = duel.players[1].field[0];
  assert.ok(witch && ally && foe);
  const refused = useSkill(duel, witch.uid, foe.uid, 0, true);
  assert.equal(refused.players[1].field[0]?.cardId, "rong-con");
  assert.match(refused.live, /bất tử/);
  const grown = useSkill(duel, witch.uid, ally.uid, 1, true, "hit");
  assert.equal(grown.players[0].field[1]?.cardId, "rong-ngan-tuoi");
  assert.equal(grown.players[0].field[1]?.atk, 7);
  const foeGrown = useSkill(duel, witch.uid, foe.uid, 1, true, "hit");
  assert.equal(foeGrown.players[1].field[0]?.cardId, "rong-ngan-tuoi");
});
test("time witch ages by 35 percent and the wheel can miss", () => {
  let duel = createDuel({ monsters: ["phu-thuy-thoi-gian"], spells: ["mua-ma-thuat"] }, "test");
  duel = testGrant(duel, 0, "phu-thuy-thoi-gian", true);
  duel = testGrant(duel, 0, "cuc-bong-ma-quai", true);
  duel = testGrant(duel, 0, "kiem-si-lua-thieng", true);
  duel = testGrant(duel, 1, "cuc-bong-ma-quai", true);
  duel = testGrant(duel, 1, "te-giac-be-con", true);
  const witch = duel.players[0].field[0];
  const cotton = duel.players[0].field[1];
  const sword = duel.players[0].field[2];
  const foe = duel.players[1].field[0];
  const rhino = duel.players[1].field[1];
  assert.ok(witch && cotton && sword && foe && rhino);
  duel = {
    ...duel,
    players: [
      {
        ...duel.players[0],
        orb: 2,
        field: [
          witch,
          { ...cotton, atk: 10, def: 10, mdef: 10, hp: 10, maxHp: 10 },
          { ...sword, atk: 10, def: 4, mdef: 4, hp: 8, maxHp: 8 },
        ],
      },
      {
        ...duel.players[1],
        field: [{ ...foe, atk: 10, def: 10, mdef: 10, hp: 10, maxHp: 10 }, rhino, null],
      },
    ],
  };
  const witchNow = duel.players[0].field[0];
  const cottonNow = duel.players[0].field[1];
  const swordNow = duel.players[0].field[2];
  const foeNow = duel.players[1].field[0];
  const rhinoNow = duel.players[1].field[1];
  assert.ok(witchNow && cottonNow && swordNow && foeNow && rhinoNow);
  assert.equal(chronoHighAlly(duel, witchNow.uid, swordNow.uid), true);
  assert.equal(chronoHighAlly(duel, witchNow.uid, cottonNow.uid), false);
  const agedFoe = useSkill(duel, witchNow.uid, foeNow.uid, 0, true);
  assert.equal(agedFoe.players[1].field[0]?.atk, 6);
  assert.equal(agedFoe.players[1].field[0]?.hp, 6);
  assert.equal(agedFoe.players[0].field[0]?.dim, true);
  const agedAlly = useSkill(duel, witchNow.uid, cottonNow.uid, 0, true);
  assert.equal(agedAlly.players[0].field[1]?.atk, 14);
  assert.equal(agedAlly.players[0].field[1]?.hp, 14);
  assert.match(agedAlly.live, /Lão hoá trưởng thành hoá .+ tăng 35% chỉ số/);
  const skipped = useSkill(duel, witchNow.uid, swordNow.uid, 0, true);
  assert.equal(skipped.players[0].field[2]?.atk, 10);
  assert.equal(skipped.players[0].field[0]?.dim, false);
  assert.match(skipped.live, /2 sao trở xuống/);
  const missed = useSkill(duel, witchNow.uid, foeNow.uid, 1, true, "miss");
  assert.equal(
    missed.players[0].field.some((mon) => mon?.cardId === "phu-thuy-thoi-gian"),
    false,
  );
  assert.equal(missed.players[1].field[0]?.atk, 10);
  assert.match(missed.live, /tự huỷ/);
  const killed = useSkill(duel, witchNow.uid, foeNow.uid, 1, true, "hit");
  assert.equal(killed.players[1].field[0], null);
  assert.equal(killed.players[0].field[0]?.dim, true);
  const rhinoHit = useSkill(duel, witchNow.uid, rhinoNow.uid, 1, true, "hit");
  assert.equal(
    rhinoHit.players[1].field.some((mon) => mon?.cardId === "te-giac-be-con"),
    false,
  );
  const plain = useSkill(duel, witchNow.uid, cottonNow.uid, 1, true, "hit");
  assert.equal(plain.players[0].field[1]?.atk, 10);
  assert.equal(plain.players[0].field[0]?.dim, true);
  const flow = useSkill(duel, witchNow.uid, null, 2, true, "miss");
  assert.equal(flow.players[0].orb, 0);
  assert.equal(
    flow.players[0].field.some((mon) => mon?.cardId === "phu-thuy-thoi-gian"),
    false,
  );
  assert.equal(flow.players[1].field[0]?.atk, 10);
  assert.equal(flow.players[0].field[2]?.atk, 10);
  const swept = useSkill(duel, witchNow.uid, null, 2, true, "hit");
  assert.equal(swept.players[0].orb, 0);
  assert.equal(swept.players[0].field[0]?.dim, true);
  assert.equal(swept.players[0].field[1]?.atk, 14);
  assert.equal(swept.players[0].field[2]?.atk, 10);
  assert.equal(swept.players[1].field[0], null);
  assert.equal(
    swept.players[1].field.some((mon) => mon?.cardId === "te-giac-be-con"),
    false,
  );
  assert.match(swept.live, /Lão hoá tiêu diệt Cục bông ma quái, Tê giác bé con/);
  assert.match(swept.live, /Lão hoá làm trưởng thành Cục bông ma quái, tăng 35% chỉ số/);
});
function dragonBoard(atk, extra = 0) {
  const base = fielded();
  const a = base.players[0].field[0];
  const d = base.players[1].field[0];
  if (!a || !d) throw new Error("field");
  const mate =
    extra > 0 ? { ...a, uid: "mate", atk: extra, def: 0, hp: 40, maxHp: 40, dim: false } : null;
  return {
    ...base,
    players: [
      { ...base.players[0], orb: 2, field: [{ ...a, atk, def: 0, hp: 40, maxHp: 40 }, mate, null] },
      {
        ...base.players[1],
        field: [
          { ...d, cardId: "chien-binh-rong", atk: 5, def: 2, mdef: 2, hp: 8, maxHp: 8 },
          null,
          null,
        ],
      },
    ],
  };
}
__name(dragonBoard, "dragonBoard");
function swing(
  duel,
  attacker = duel.players[0].field[0]?.uid ?? "",
  defender = duel.players[1].field[0]?.uid ?? "",
) {
  return passResponse(passResponse(attackMonster(duel, attacker, defender)));
}
__name(swing, "swing");
test("chi\u1EBFn binh r\u1ED3ng splits 11 physical into 4 before defense", () => {
  const hit = swing(dragonBoard(11));
  const dragon = hit.players[1].field[0];
  assert.ok(dragon);
  assert.equal(dragon.hp, 6);
  assert.deepEqual(dragon.debt, [
    { p: 4, s: 0, t: 0 },
    { p: 4, s: 0, t: 0 },
  ]);
  const next = endTurn(hit);
  const owed = next.players[1].field[0];
  assert.ok(owed);
  assert.equal(owed.hp, 4);
  assert.deepEqual(owed.debt, [
    { p: 4, s: 0, t: 0 },
    { p: 0, s: 0, t: 0 },
  ]);
  assert.match(next.live, /Chiến binh rồng nhận 2 sát thương vật lý/);
  const last = endTurn(next);
  const done = last.players[1].field[0];
  assert.ok(done);
  assert.equal(done.hp, 2);
  assert.equal(done.debt, void 0);
});
test("chi\u1EBFn binh r\u1ED3ng drops a remainder of 1 and hides a zero slice", () => {
  const ten = swing(dragonBoard(10)).players[1].field[0];
  assert.ok(ten);
  assert.equal(ten.hp, 7);
  assert.deepEqual(ten.debt?.[0], { p: 3, s: 0, t: 0 });
  const one = swing(dragonBoard(1)).players[1].field[0];
  assert.ok(one);
  assert.equal(one.hp, 8);
  assert.equal(one.debt, void 0);
});
test("chi\u1EBFn binh r\u1ED3ng adds queued hits of one type and subtracts defense once", () => {
  const board = dragonBoard(5, 6);
  const first = swing(board);
  const second = swing(first, "mate");
  const dragon = second.players[1].field[0];
  assert.ok(dragon);
  assert.equal(dragon.hp, 8);
  assert.deepEqual(dragon.debt?.[0], { p: 4, s: 0, t: 0 });
  const paid = endTurn(second).players[1].field[0];
  assert.ok(paid);
  assert.equal(paid.hp, 6);
  assert.deepEqual(paid.debt?.[0], { p: 4, s: 0, t: 0 });
});
test("chi\u1EBFn binh r\u1ED3ng splits spell and true damage and skips zero on the next turn", () => {
  const board = dragonBoard(1);
  const caster = board.players[0].field[0];
  const dragon = board.players[1].field[0];
  assert.ok(caster && dragon);
  const armed = {
    ...board,
    players: [
      {
        ...board.players[0],
        field: [{ ...caster, cardId: "rong-con", atk: 2, hp: 2, maxHp: 2 }, null, null],
      },
      board.players[1],
    ],
  };
  const burned = useSkill(armed, caster.uid, dragon.uid, 0, true);
  const hit = burned.players[1].field[0];
  assert.ok(hit);
  assert.equal(hit.hp, 7);
  assert.deepEqual(hit.debt, [
    { p: 0, s: 1, t: 1 },
    { p: 0, s: 1, t: 1 },
  ]);
  const next = endTurn(burned);
  const owed = next.players[1].field[0];
  assert.ok(owed);
  assert.equal(owed.hp, 6);
  assert.match(next.live, /1 sát thương chuẩn/);
  assert.doesNotMatch(next.live, /sát thương phép/);
});
test("ma \u0111\u1EA1o s\u0129 fires three spell shots at one monster or the player", () => {
  const base = fielded();
  const caster = base.players[0].field[0];
  const foe = base.players[1].field[0];
  assert.ok(caster && foe);
  const duel = {
    ...base,
    players: [
      {
        ...base.players[0],
        orb: 2,
        field: [
          { ...caster, cardId: "ma-dao-si", atk: 2, def: 3, mdef: 1, hp: 5, maxHp: 5 },
          null,
          null,
        ],
      },
      {
        ...base.players[1],
        hp: 20,
        field: [{ ...foe, hp: 20, maxHp: 20, def: 0, mdef: 2, atk: 0 }, null, null],
      },
    ],
  };
  const hit = useSkill(duel, caster.uid, foe.uid, 0, true);
  assert.equal(hit.players[1].field[0]?.hp, 17);
  assert.equal(hit.players[0].orb, 1);
  assert.equal(hit.players[0].field[0]?.dim, true);
  assert.deepEqual(hit.skill?.vols, [1, 1, 1]);
  assert.equal(hit.skill?.hits?.length, 3);
  const face = useSkill(duel, caster.uid, null, 0, true);
  assert.equal(face.players[1].hp, 11);
  assert.equal(face.players[1].field[0]?.hp, 20);
  assert.deepEqual(face.skill?.vols, [3, 3, 3]);
});
test("l\u1EDDi nguy\u1EC1n c\u1EE7a r\u1ED3ng splashes 2 true damage after aiming one enemy", () => {
  const base = fielded();
  const caster = base.players[0].field[0];
  const foe = base.players[1].field[0];
  assert.ok(caster && foe);
  const tank = { ...foe, def: 9, mdef: 9, hp: 9, maxHp: 9 };
  const dragon = {
    ...foe,
    uid: `${foe.uid}-rong`,
    cardId: "chien-binh-rong",
    atk: 5,
    def: 9,
    mdef: 9,
    hp: 8,
    maxHp: 8,
  };
  const duel = {
    ...base,
    players: [
      {
        ...base.players[0],
        orb: 3,
        hp: 20,
        field: [
          { ...caster, cardId: "loi-nguyen-cua-rong", atk: 4, def: 1, mdef: 3, hp: 4, maxHp: 4 },
          null,
          null,
        ],
      },
      { ...base.players[1], hp: 20, field: [tank, dragon, null] },
    ],
  };
  const curse = duel.players[0].field[0];
  assert.ok(curse);
  const missed = useSkill(duel, curse.uid, null, 0, true);
  assert.equal(missed.players[1].field[0]?.hp, 9);
  assert.equal(missed.players[1].hp, 20);
  const bare = declareSkill(duel, curse.uid, null, 0);
  assert.equal(bare.pending, null);
  const aimed = declareSkill(duel, curse.uid, tank.uid, 0);
  assert.equal(aimed.pending?.kind, "beam");
  if (aimed.pending?.kind === "beam") assert.equal(aimed.pending.target, tank.uid);
  const hit = useSkill(duel, curse.uid, tank.uid, 0, true);
  assert.equal(hit.players[1].field[0]?.hp, 7);
  assert.equal(hit.players[1].field[1]?.hp, 7);
  assert.deepEqual(hit.players[1].field[1]?.debt, [
    { p: 0, s: 0, t: 1 },
    { p: 0, s: 0, t: 1 },
  ]);
  assert.equal(hit.players[1].hp, 20);
  assert.equal(hit.players[0].hp, 20);
  assert.equal(hit.players[0].orb, 3);
  const marks = hit.skill?.hits ?? [];
  assert.ok(marks.includes(tank.uid));
  assert.ok(marks.includes(dragon.uid));
  assert.equal(hit.players[0].field[0]?.dim, true);
  const reflecting = {
    ...duel,
    turn: 1,
    players: [
      {
        ...duel.players[1],
        hand: ["giap-co-khi"],
        tolls: [false],
        field: [{ ...tank, atk: 10 }, null, null],
      },
      { ...duel.players[0], field: [{ ...curse, mdef: 9, hp: 8, maxHp: 8 }, null, null] },
    ],
  };
  const body = reflecting.players[1].field[0];
  const ally = reflecting.players[0].field[0];
  assert.ok(body && ally);
  const bounced = passResponse(
    castSpell(declareSkill(reflecting, body.uid, ally.uid, 0), 0, ally.uid),
  );
  assert.equal(bounced.players[0].field[0]?.atk, 12);
  assert.equal(bounced.players[0].field[0]?.hp, 9);
  assert.equal(bounced.players[1].field[0]?.hp, 6);
});

test("demon dragon fusion deals 6 true damage to a monster or the player", () => {
  assert.equal(findFusion("mat-do-tan-pha", "trieu-hoi-ac-ma")?.result, "rong-ac-ma");
  let duel = createDuel({ monsters: ["phu-thuy-thoi-gian"], spells: ["mua-ma-thuat"] }, "test");
  duel = testGrant(duel, 0, "rong-ac-ma", true);
  duel = testGrant(duel, 1, "cuc-bong-ma-quai", true);
  const caster = duel.players[0].field[0];
  const cotton = duel.players[1].field[0];
  assert.ok(caster && cotton);
  duel = {
    ...duel,
    players: [
      duel.players[0],
      { ...duel.players[1], hp: 20, field: [{ ...cotton, def: 9, hp: 20, maxHp: 20 }, null, null] },
    ],
  };
  const hit = passResponse(declareSkill(duel, caster.uid, cotton.uid, 0));
  assert.equal(hit.players[1].field[0]?.hp, 14);
  assert.match(hit.live, /Hoả cầu địa ngục gây 6 sát thương chuẩn/);
  const face = passResponse(declareSkill(duel, caster.uid, null, 0));
  assert.equal(face.players[1].hp, 14);
  assert.match(face.live, /lên người chơi/);
});

test("demon pact only starts at 3 stars, not when the player already has 4", () => {
  const deck = {
    monsters: ["trieu-hoi-ac-ma", "trieu-hoi-ac-ma", "trieu-hoi-ac-ma", "trieu-hoi-ac-ma"],
    spells: ["mua-ma-thuat", "mua-ma-thuat"],
  };
  const ready = createDuel(deck, "test");
  const full = summon(ready, 0, 0);
  assert.equal(full.players[0].field[0]?.cardId, "trieu-hoi-ac-ma");
  assert.equal(Boolean(full.players[0].field[0]?.pact), false);
  assert.equal(full.players[0].orb, 3);
  assert.doesNotMatch(full.live, /khế ước|1 mana/);
  const early = summon(
    {
      ...ready,
      players: [{ ...ready.players[0], stars: 3 }, ready.players[1]],
    },
    0,
    0,
  );
  assert.equal(early.players[0].field[0]?.pact, true);
  assert.equal(early.players[0].orb, 2);
  assert.match(early.live, /khế ước/);
});

test("little angel shield blocks one matching hit then breaks", () => {
  let duel = createDuel(
    {
      monsters: ["cuc-bong-ma-quai", "cuc-bong-ma-quai", "cuc-bong-ma-quai", "cuc-bong-ma-quai"],
      spells: ["mua-ma-thuat", "mua-ma-thuat"],
    },
    "test",
  );
  duel = testGrant(duel, 0, "thien-than-be-nho", true);
  duel = testGrant(duel, 0, "cuc-bong-ma-quai", true);
  duel = testGrant(duel, 1, "chien-si-gam-nham", true);
  const angel = duel.players[0].field.find((mon) => mon?.cardId === "thien-than-be-nho");
  const cotton = duel.players[0].field.find((mon) => mon?.cardId === "cuc-bong-ma-quai");
  const foe = duel.players[1].field.find((mon) => mon?.cardId === "chien-si-gam-nham");
  assert.ok(angel && cotton && foe);
  duel = useSkill(duel, angel.uid, cotton.uid, 0, true);
  assert.equal(duel.players[0].field.find((mon) => mon?.uid === cotton.uid)?.ward, "phys");
  duel = {
    ...duel,
    turn: 1,
    players: [
      {
        ...duel.players[0],
        field: duel.players[0].field.map((mon) => (mon?.uid === cotton.uid ? { ...mon, def: 0, hp: 8, maxHp: 8 } : mon)) as typeof duel.players[0]["field"],
      },
      {
        ...duel.players[1],
        field: duel.players[1].field.map((mon) => (mon?.uid === foe.uid ? { ...mon, atk: 4, hp: 8, maxHp: 8 } : mon)) as typeof duel.players[1]["field"],
      },
    ],
  };
  const struck = passResponse(attackMonster(duel, foe.uid, cotton.uid));
  const body = struck.players[0].field.find((mon) => mon?.uid === cotton.uid);
  assert.equal(body?.hp, 8);
  assert.equal(body?.ward, undefined);
  assert.match(struck.live, /Khiên vật lý đã vỡ/);
});

test("red eye mixed hit names each damage and a spell shield blocks only the spell", () => {
  let duel = createDuel(
    {
      monsters: ["cuc-bong-ma-quai", "cuc-bong-ma-quai", "cuc-bong-ma-quai", "cuc-bong-ma-quai"],
      spells: ["mua-ma-thuat", "mua-ma-thuat"],
    },
    "test",
  );
  duel = testGrant(duel, 0, "cuc-bong-ma-quai", true);
  duel = testGrant(duel, 1, "mat-do-tan-pha", true);
  const cotton = duel.players[0].field.find((mon) => mon?.cardId === "cuc-bong-ma-quai");
  const eye = duel.players[1].field.find((mon) => mon?.cardId === "mat-do-tan-pha");
  assert.ok(cotton && eye);
  duel = {
    ...duel,
    turn: 1,
    players: [
      {
        ...duel.players[0],
        field: duel.players[0].field.map((mon) => (mon?.uid === cotton.uid ? { ...mon, def: 0, mdef: 0, hp: 20, maxHp: 20, ward: "spell" } : mon)) as typeof duel.players[0]["field"],
      },
      {
        ...duel.players[1],
        orb: 5,
        field: duel.players[1].field.map((mon) => (mon?.uid === eye.uid ? { ...mon, dim: false } : mon)) as typeof duel.players[1]["field"],
      },
    ],
  };
  const hit = useSkill(duel, eye.uid, cotton.uid, 0, true);
  const body = hit.players[0].field.find((mon) => mon?.uid === cotton.uid);
  assert.equal(body?.hp, 14);
  assert.equal(body?.ward, undefined);
  assert.match(hit.live, /4 sát thương vật lý/);
  assert.match(hit.live, /2 sát thương chuẩn/);
  assert.doesNotMatch(hit.live, /0 sát thương phép/);
  assert.match(hit.live, /Khiên phép đã vỡ/);
});

test("harpy skills spend once, dodge or cancel, and lock the next draw", () => {
  let duel = createDuel(
    {
      monsters: ["cuc-bong-ma-quai", "cuc-bong-ma-quai", "cuc-bong-ma-quai", "cuc-bong-ma-quai"],
      spells: ["mua-ma-thuat", "mua-ma-thuat", "mua-ma-thuat", "mua-ma-thuat"],
    },
    "test",
  );
  duel = testGrant(duel, 0, "my-dieu-nhan", true);
  duel = testGrant(duel, 1, "phu-thuy-ti-hon", true);
  duel = { ...duel, players: [{ ...duel.players[0], hand: ["mua-ma-thuat"] }, { ...duel.players[1], hand: ["mua-ma-thuat", "sung-loi-pha"] }] as typeof duel.players };
  const bird = duel.players[0].field.find((mon) => mon?.cardId === "my-dieu-nhan");
  const witch = duel.players[1].field.find((mon) => mon?.cardId === "phu-thuy-ti-hon");
  assert.ok(bird && witch);
  const blown = useSkill(duel, bird.uid, null, 0);
  assert.equal(blown.players[1].hand.length, 1);
  assert.equal(blown.players[0].drawBan, 1);
  assert.ok(blown.players[0].field.find((mon) => mon?.uid === bird.uid)?.shed?.includes("gust"));
  const awake = {
    ...blown,
    players: [
      { ...blown.players[0], field: blown.players[0].field.map((mon) => (mon?.uid === bird.uid ? { ...mon, dim: false } : mon)) },
      blown.players[1],
    ] as typeof blown.players,
  };
  const again = useSkill(awake, bird.uid, null, 0);
  assert.match(again.live, /đã biến mất/);
  let armed = endTurn(blown);
  armed = endTurn({ ...armed, players: [{ ...armed.players[0] }, { ...armed.players[1], field: armed.players[1].field.map((mon) => (mon ? { ...mon, dim: false } : mon)) }] as typeof armed.players });
  assert.equal(armed.turn, 0);
  assert.equal(armed.players[0].drawLock, true);
  const locked = draw(armed, "spell");
  assert.match(locked.live, /không được rút/);
  let fight = createDuel(
    {
      monsters: ["cuc-bong-ma-quai", "cuc-bong-ma-quai", "cuc-bong-ma-quai", "cuc-bong-ma-quai"],
      spells: ["mua-ma-thuat", "mua-ma-thuat"],
    },
    "test",
  );
  fight = testGrant(fight, 0, "my-dieu-nhan", true);
  fight = testGrant(fight, 1, "phu-thuy-ti-hon", true);
  fight = endTurn(fight);
  const nest = fight.players[0].field.find((mon) => mon?.cardId === "my-dieu-nhan");
  const foe = fight.players[1].field.find((mon) => mon?.cardId === "phu-thuy-ti-hon");
  assert.ok(nest && foe);
  const aimed = declareSkill(fight, foe.uid, nest.uid, 0);
  assert.equal(harpyOffer(aimed, 0), "armor");
  const warded = harpyWard(aimed);
  assert.equal(warded.pending, null);
  const shielded = warded.players[0].field.find((mon) => mon?.uid === nest.uid);
  assert.equal(shielded?.def, 3);
  assert.equal(shielded?.maxHp, 6);
  assert.equal(shielded?.hp, 6);
  let swing = createDuel(
    {
      monsters: ["cuc-bong-ma-quai", "cuc-bong-ma-quai", "cuc-bong-ma-quai", "cuc-bong-ma-quai"],
      spells: ["mua-ma-thuat", "mua-ma-thuat"],
    },
    "test",
  );
  swing = testGrant(swing, 0, "my-dieu-nhan", true);
  swing = testGrant(swing, 1, "cuc-bong-ma-quai", true);
  swing = endTurn(swing);
  const home = swing.players[0].field.find((mon) => mon?.cardId === "my-dieu-nhan");
  const brute = swing.players[1].field.find((mon) => mon?.cardId === "cuc-bong-ma-quai");
  assert.ok(home && brute);
  const melee = attackMonster(swing, brute.uid, home.uid);
  assert.equal(harpyOffer(melee, 0), "lash");
  const opened = harpyLash(melee);
  assert.equal(opened.pending?.kind, "lash");
  assert.match(opened.live, /né đòn/);
  const shocked = passResponse(opened);
  const flyer = shocked.players[0].field.find((mon) => mon?.uid === home.uid);
  assert.equal(flyer?.atk, 6);
  assert.equal(flyer?.hp, 4);
  assert.match(shocked.live, /sát thương phép/);
  assert.equal(shocked.pending, null);
});

test("bird girl can choose the queen and the new form starts from its own stats", () => {
  let duel = createDuel(
    {
      monsters: ["cuc-bong-ma-quai", "cuc-bong-ma-quai", "cuc-bong-ma-quai", "cuc-bong-ma-quai"],
      spells: ["mua-ma-thuat", "mua-ma-thuat"],
    },
    "test",
  );
  duel = testGrant(duel, 0, "my-dieu-nhan", true);
  const bird = duel.players[0].field.find((mon) => mon?.cardId === "my-dieu-nhan");
  assert.ok(bird);
  duel = {
    ...duel,
    players: [
      {
        ...duel.players[0],
        field: duel.players[0].field.map((mon) => (mon?.uid === bird.uid ? { ...mon, shed: ["armor", "charm", "lash"], atk: 9, def: 7, hp: 9, maxHp: 9 } : mon)),
      },
      { ...duel.players[1], hand: ["mua-ma-thuat"] },
    ] as typeof duel.players,
  };
  const asked = useSkill(duel, bird.uid, null, 0);
  assert.equal(asked.birdAsk?.uid, bird.uid);
  const missing = evolveBird(asked, "cong-chua-dieu-nhan");
  assert.match(missing.live, /bổ sung sau/);
  assert.equal(missing.birdAsk?.uid, bird.uid);
  const born = evolveBird(asked, "nu-chua-dieu-nhan");
  const queen = born.players[0].field.find((mon) => mon?.uid === bird.uid);
  assert.equal(queen?.cardId, "nu-chua-dieu-nhan");
  assert.equal(queen?.atk, 6);
  assert.equal(queen?.def, 3);
  assert.equal(queen?.mdef, 1);
  assert.equal(queen?.hp, 6);
  assert.equal(queen?.shed?.length ?? 0, 0);
  assert.equal(queen?.acts ?? 0, 0);
  const stocked = {
    ...born,
    players: [
      { ...born.players[0], field: born.players[0].field.map((mon) => (mon?.uid === bird.uid ? { ...mon, dim: false } : mon)) },
      { ...born.players[1], hand: ["sung-loi-pha"] },
    ] as typeof born.players,
  };
  const gust = useSkill(stocked, bird.uid, null, 0);
  assert.equal(gust.players[0].orb, stocked.players[0].orb);
  assert.match(gust.live, /Thổi bay/);
});

test("queen can evolve charm into lure, which stays and counts as an action", () => {
  let duel = createDuel(
    {
      monsters: ["cuc-bong-ma-quai", "cuc-bong-ma-quai", "cuc-bong-ma-quai", "cuc-bong-ma-quai"],
      spells: ["mua-ma-thuat", "mua-ma-thuat"],
    },
    "test",
  );
  duel = testGrant(duel, 0, "nu-chua-dieu-nhan", true);
  duel = testGrant(duel, 1, "cuc-bong-ma-quai", true);
  const queen = duel.players[0].field.find((mon) => mon?.cardId === "nu-chua-dieu-nhan");
  const foe = duel.players[1].field.find((mon) => mon?.cardId === "cuc-bong-ma-quai");
  assert.ok(queen && foe);
  duel = {
    ...duel,
    players: [
      duel.players[0],
      {
        ...duel.players[1],
        field: duel.players[1].field.map((mon) => (mon?.uid === foe.uid ? { ...mon, hp: 40, maxHp: 40 } : mon)),
      },
    ] as typeof duel.players,
  };
  const before = duel.players[0].orb;
  const lured = useSkill(duel, queen.uid, queen.uid, 3, true, foe.uid);
  const body = lured.players[0].field.find((mon) => mon?.uid === queen.uid);
  const brute = lured.players[1].field.find((mon) => mon?.uid === foe.uid);
  assert.equal(lured.players[0].orb, before - 2);
  assert.equal(body?.lure, true);
  assert.equal(body?.dim, true);
  assert.equal(body?.acts, 1);
  assert.equal(body?.shed?.includes("charm") ?? false, false);
  assert.equal(lured.players[0].drawBan ?? 0, 0);
  assert.equal(brute?.stun ?? 0, 0);
  assert.equal(brute?.dim ?? false, false);
  assert.match(lured.live, /dụ dỗ/);
  assert.match(lured.live, /sáp lá cà/);
  const again = useSkill(
    { ...lured, players: [{ ...lured.players[0], field: lured.players[0].field.map((mon) => (mon?.uid === queen.uid ? { ...mon, dim: false } : mon)) }, lured.players[1]] as typeof lured.players },
    queen.uid,
    queen.uid,
    3,
    true,
    foe.uid,
  );
  const kept = again.players[0].field.find((mon) => mon?.uid === queen.uid);
  assert.equal(again.players[0].orb, lured.players[0].orb);
  assert.equal(kept?.lure, true);
  assert.equal(kept?.acts, 2);
});

test("perfect queen banks blocked damage and spends it on the next hit", () => {
  let duel = createDuel(
    {
      monsters: ["cuc-bong-ma-quai", "cuc-bong-ma-quai", "cuc-bong-ma-quai", "cuc-bong-ma-quai"],
      spells: ["mua-ma-thuat", "mua-ma-thuat"],
    },
    "test",
  );
  duel = testGrant(duel, 0, "nu-chua-dieu-nhan-hoan-my", true);
  duel = testGrant(duel, 1, "cuc-bong-ma-quai", true);
  const queen = duel.players[0].field.find((mon) => mon?.cardId === "nu-chua-dieu-nhan-hoan-my");
  const foe = duel.players[1].field.find((mon) => mon?.cardId === "cuc-bong-ma-quai");
  assert.ok(queen && foe);
  duel = {
    ...duel,
    turn: 1 as const,
    players: [
      duel.players[0],
      {
        ...duel.players[1],
        field: duel.players[1].field.map((mon) => (mon?.uid === foe.uid ? { ...mon, atk: 2, def: 0, hp: 40, maxHp: 40 } : mon)),
      },
    ] as typeof duel.players,
  };
  const hit = passResponse(attackMonster(duel, foe.uid, queen.uid));
  const body = hit.players[0].field.find((mon) => mon?.uid === queen.uid);
  const brute = hit.players[1].field.find((mon) => mon?.uid === foe.uid);
  assert.equal(body?.hp, queen.hp);
  assert.equal(body?.debt?.[0].p, 2);
  assert.equal(brute?.hp, 40 - queen.atk);
  const armed = {
    ...hit,
    turn: 0 as const,
    players: [
      {
        ...hit.players[0],
        field: hit.players[0].field.map((mon) => (mon?.uid === queen.uid ? { ...mon, dim: false, bolt: true, debt: [{ p: 2, s: 3, t: 0 }, { p: 0, s: 0, t: 0 }] as const } : mon)),
      },
      {
        ...hit.players[1],
        field: hit.players[1].field.map((mon) => (mon?.uid === foe.uid ? { ...mon, atk: 0, def: 0, mdef: 0, hp: 40, maxHp: 40, dim: false } : mon)),
      },
    ] as typeof hit.players,
  };
  const swung = passResponse(attackMonster(armed, queen.uid, foe.uid));
  const after = swung.players[1].field.find((mon) => mon?.uid === foe.uid);
  const bird = swung.players[0].field.find((mon) => mon?.uid === queen.uid);
  assert.equal(after?.hp, 40 - (queen.atk + 2 + 3));
  assert.equal(bird?.bolt, undefined);
  assert.equal(bird?.debt, undefined);
  const gust = useSkill(
    {
      ...swung,
      players: [
        { ...swung.players[0], field: swung.players[0].field.map((mon) => (mon?.uid === queen.uid ? { ...mon, dim: false } : mon)) },
        swung.players[1],
      ] as typeof swung.players,
    },
    queen.uid,
    null,
    0,
    true,
  );
  assert.equal(gust.players[0].field.find((mon) => mon?.uid === queen.uid)?.dim ?? false, false);
  assert.equal(gust.players[0].drawBan, 1);
  const open = {
    ...gust,
    players: [{ ...gust.players[0], orb: 3, field: gust.players[0].field.map((mon) => (mon?.uid === queen.uid ? { ...mon, dim: true } : mon)) }, gust.players[1]] as typeof gust.players,
  };
  const bolt = useSkill(open, queen.uid, null, 2, true);
  assert.equal(bolt.players[0].orb, 2);
  assert.equal(bolt.players[0].field.find((mon) => mon?.uid === queen.uid)?.bolt, true);
  assert.equal(bolt.players[0].field.find((mon) => mon?.uid === queen.uid)?.dim, true);
});

test("queen evolves into the perfect form once four skills and two actions are done", () => {
  let duel = createDuel(
    {
      monsters: ["cuc-bong-ma-quai", "cuc-bong-ma-quai", "cuc-bong-ma-quai", "cuc-bong-ma-quai"],
      spells: ["mua-ma-thuat", "mua-ma-thuat"],
    },
    "test",
  );
  duel = testGrant(duel, 0, "nu-chua-dieu-nhan", true);
  duel = testGrant(duel, 1, "cuc-bong-ma-quai", true);
  const queen = duel.players[0].field.find((mon) => mon?.cardId === "nu-chua-dieu-nhan");
  const foe = duel.players[1].field.find((mon) => mon?.cardId === "cuc-bong-ma-quai");
  assert.ok(queen && foe);
  duel = {
    ...duel,
    players: [
      {
        ...duel.players[0],
        field: duel.players[0].field.map((mon) =>
          mon?.uid === queen.uid ? { ...mon, lure: true, acts: 1, shed: ["armor", "gust", "charm", "lash"], hp: 20, maxHp: 20 } : mon,
        ),
      },
      {
        ...duel.players[1],
        field: duel.players[1].field.map((mon) => (mon?.uid === foe.uid ? { ...mon, hp: 40, maxHp: 40 } : mon)),
      },
    ] as typeof duel.players,
  };
  const evolved = useSkill(duel, queen.uid, queen.uid, 3, true, foe.uid);
  const born = evolved.players[0].field.find((mon) => mon?.uid === queen.uid);
  assert.equal(born?.cardId, "nu-chua-dieu-nhan-hoan-my");
  assert.equal(born?.atk, 6);
  assert.equal(born?.def, 3);
  assert.equal(born?.mdef, 3);
  assert.equal(born?.hp, 8);
  assert.match(evolved.live, /tiến hoá/);
});

test("beast shield is one action and stays dim so it cannot fire twice", () => {
  let duel = createDuel({ monsters: ["phu-thuy-thoi-gian"], spells: ["mua-ma-thuat"] }, "test");
  duel = testGrant(duel, 0, "may-chem", true);
  duel = testGrant(duel, 1, "chien-si-gam-nham", true);
  const axe = duel.players[0].field[0];
  const gnaw = duel.players[1].field[0];
  assert.ok(axe && gnaw);
  const swung = attackMonster(duel, axe.uid, gnaw.uid);
  const once = boostGnawOnChain(swung, gnaw.uid);
  const body = once.players[1].field.find((mon) => mon?.uid === gnaw.uid);
  assert.equal(body?.dim, true);
  assert.equal(body?.def, gnaw.def * 2);
  const twice = boostGnawOnChain(once, gnaw.uid);
  assert.equal(twice.players[1].field.find((mon) => mon?.uid === gnaw.uid)?.def, body?.def);
  assert.equal(twice.players[1].orb, once.players[1].orb);
  const face = attackFace(duel, axe.uid);
  const blocked = assignBlock(face, gnaw.uid, true);
  assert.equal(blocked.hold?.blocker, gnaw.uid);
  assert.equal(blocked.players[1].field.find((mon) => mon?.uid === gnaw.uid)?.dim, true);
  const again = boostGnawOnChain(blocked, gnaw.uid);
  assert.equal(again.players[1].field.find((mon) => mon?.uid === gnaw.uid)?.def, blocked.players[1].field.find((mon) => mon?.uid === gnaw.uid)?.def);
  const hit = passResponse(blocked);
  assert.equal(hit.players[1].hp, 20);
});

test("fairy guard lasts only for the block", () => {
  let duel = createDuel({ monsters: ["phu-thuy-thoi-gian"], spells: ["mua-ma-thuat"] }, "test");
  duel = testGrant(duel, 0, "may-chem", true);
  duel = testGrant(duel, 1, "yeu-tinh-chuc-phuc", true);
  duel = testGrant(duel, 1, "linh-chien-da-khong-lo", true);
  const axe = duel.players[0].field[0];
  const guard = duel.players[1].field.find((mon) => mon?.cardId === "linh-chien-da-khong-lo");
  assert.ok(axe && guard);
  const blocked = assignBlock(attackFace(duel, axe.uid), guard.uid);
  const blessed = answerFairy(blocked, guard.uid, true);
  const during = blessed.players[1].field.find((mon) => mon?.uid === guard.uid);
  assert.equal(during?.tempGuard, 1);
  assert.equal(during?.def, guard.def);
  const hit = passResponse(blessed);
  const after = hit.players[1].field.find((mon) => mon?.uid === guard.uid);
  assert.equal(after?.tempGuard ?? 0, 0);
  assert.equal(after?.def, guard.def);
  assert.equal(after?.hp, guard.hp);
});

test("fairy aid costs 1 mana and buffs only the next blow", () => {
  let duel = createDuel({ monsters: ["phu-thuy-thoi-gian"], spells: ["mua-ma-thuat"] }, "test");
  duel = testGrant(duel, 0, "yeu-tinh-chuc-phuc", true);
  duel = testGrant(duel, 0, "cuc-bong-ma-quai", true);
  const fairy = duel.players[0].field.find((mon) => mon?.cardId === "yeu-tinh-chuc-phuc");
  const ally = duel.players[0].field.find((mon) => mon?.cardId === "cuc-bong-ma-quai");
  assert.ok(fairy && ally);
  const broke = useSkill({ ...duel, players: [{ ...duel.players[0], orb: 0 }, duel.players[1]] }, fairy.uid, ally.uid, 0);
  assert.equal(broke.players[0].orb, 0);
  assert.equal(broke.players[0].field.find((mon) => mon?.uid === ally.uid)?.blessAtk ?? 0, 0);
  const cast = useSkill(duel, fairy.uid, ally.uid, 0);
  assert.equal(cast.players[0].orb, 2);
  const buffed = cast.players[0].field.find((mon) => mon?.uid === ally.uid);
  assert.equal(buffed?.blessAtk, 3);
  assert.equal(buffed?.blessDmg, 3);
  assert.equal(buffed?.nextDef, 1);
  assert.equal(cast.players[0].field.find((mon) => mon?.uid === fairy.uid)?.dim, true);
  const poor = { ...duel, players: [{ ...duel.players[0], orb: 0 }, duel.players[1]] as typeof duel.players };
  const dry = answerFairy(poor, ally.uid, true);
  assert.equal(dry.players[0].orb, 0);
  assert.equal(dry.players[0].field.find((mon) => mon?.uid === ally.uid)?.tempGuard ?? 0, 0);
});

test("cocoon grows only one leg", () => {
  let duel = createDuel({ monsters: ["phu-thuy-thoi-gian"], spells: ["mua-ma-thuat"] }, "test");
  duel = testGrant(duel, 0, "sau-non", true);
  const larva = duel.players[0].field.find((mon) => mon?.cardId === "sau-non");
  assert.ok(larva);
  const spun = useSkill(duel, larva.uid, null, 0);
  assert.equal(spun.players[0].field.find((mon) => mon?.uid === larva.uid)?.cardId, "ken-ngai");
  assert.equal(spun.legs, larva.uid);
  const grown = answerLegs(spun, 2);
  const legs = grown.players[0].field.filter((mon) => mon?.cardId === "chan-ken");
  assert.equal(legs.length, 1);
  assert.equal(legs[0]?.host, larva.uid);
  assert.equal(grown.legs, null);
  assert.equal(grown.players[0].orb, spun.players[0].orb - 1);
});










