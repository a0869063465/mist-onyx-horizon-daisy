import assert from "node:assert/strict";
import test from "node:test";
import { ADAPT_CAP, ADAPT_MIN_GAMES, chooseSwing, emptyLean, learnFrom, tilt } from "./adapt.ts";
import { aiStep, createDuel, endTurn, testGrant, type Duel } from "./duel.ts";

function actions(kind: string, count: number, extra: Record<string, unknown> = {}) {
  return Array.from({ length: count }, () => ({ actor: 0, ok: true, kind, orb: [1, 1], cardId: "phu-thuy-thoi-gian", auto: false, ...extra }));
}

function finished(events: unknown[], winner: 0 | 1 | null = 0) {
  return { mode: "ai", winner, events };
}

test("too few matches keep the default lean", () => {
  const lean = learnFrom([finished(actions("attack-face", 8)), finished(actions("attack-face", 8))]);
  assert.equal(lean.ready, false);
  assert.equal(lean.games, 2);
  assert.equal(lean.counts.face, 16);
  assert.equal(lean.face, 0);
  assert.equal(lean.monster, 0);
  assert.deepEqual(chooseSwing(true, true, lean), "default");
  assert.deepEqual(chooseSwing(true, true, emptyLean()), "default");
});

test("finished matches build a bounded style and ignore junk", () => {
  const rows = [
    finished(actions("attack-face", 4), 0),
    finished(actions("attack-face", 4), 0),
    finished(actions("attack-monster", 1), 1),
    finished([...actions("spell", 3), ...actions("skill", 1)], 0),
    finished([{ actor: 0, ok: true, kind: "concede", orb: [0, 0] }, ...actions("attack-face", 9)], 1),
    null,
    { mode: "hotseat", winner: 0, events: actions("attack-face", 9) },
    { mode: "ai", winner: 0 },
    { mode: "ai", winner: 3, events: [] },
  ];
  const lean = learnFrom(rows);
  assert.equal(lean.games, 5);
  assert.equal(lean.used, 4);
  assert.equal(lean.wins, 3);
  assert.equal(lean.losses, 1);
  assert.equal(lean.concedes, 1);
  assert.equal(lean.counts.face, 8);
  assert.equal(lean.ready, true);
  assert.ok(lean.face > 0);
  assert.ok(lean.face <= ADAPT_CAP);
  assert.ok(lean.monster >= -ADAPT_CAP);
  assert.equal(learnFrom(null).ready, false);
  assert.equal(learnFrom("nope").games, 0);
  const flooded = learnFrom(Array.from({ length: ADAPT_MIN_GAMES }, () => finished(actions("attack-face", 20))));
  assert.equal(flooded.face, ADAPT_CAP);
  assert.equal(tilt(5, 10_000), 5 + ADAPT_CAP);
  assert.equal(tilt(5, -10_000), 5 - ADAPT_CAP);
  const auto = learnFrom(Array.from({ length: 4 }, () => finished([{ actor: 0, ok: true, auto: true, kind: "result", orb: [1, 1] }, ...actions("attack-face", 2)])));
  assert.equal(auto.counts.face, 8);
});

test("a face lean changes the legal attack the AI picks", () => {
  let duel = createDuel({ monsters: ["phu-thuy-thoi-gian"], spells: ["mua-ma-thuat"] }, "test");
  duel = testGrant(duel, 1, "may-chem", true);
  duel = testGrant(duel, 0, "phu-thuy-thoi-gian", true);
  const axe = duel.players[1].field[0];
  assert.ok(axe);
  const board: Duel = {
    ...duel,
    mode: "ai",
    turn: 1,
    players: [
      duel.players[0],
      {
        ...duel.players[1],
        turns: 5,
        summons: 1,
        draws: 1,
        acted: false,
        attackLock: 0,
        field: [axe, { ...axe, uid: "dim-a", dim: true }, { ...axe, uid: "dim-b", dim: true }],
      },
    ],
  };
  const plain = aiStep(board);
  assert.equal(plain.pending?.kind, "melee");
  const leaned = learnFrom(Array.from({ length: 4 }, () => finished(actions("attack-face", 6))));
  const swung = aiStep({ ...board, adapt: leaned });
  assert.equal(swung.pending?.kind, "face");
  assert.equal(swung.mode, "ai");
  assert.equal(chooseSwing(true, true, leaned), "face");
  const quiet = aiStep(endTurn(createDuel(undefined, "ai")));
  assert.equal(quiet.mode, "ai");
  assert.ok(quiet.step === "main" || quiet.step === "respond" || quiet.step === "over");
});
