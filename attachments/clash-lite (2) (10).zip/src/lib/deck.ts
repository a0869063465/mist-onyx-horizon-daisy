import { DEFAULT_DECK, deckLegal, FORMS, monsterCard, spellCard } from "./catalog.ts";

const KEY = "clash-beasts-deck";
const outside = new Set(FORMS.map((card) => card.id));

export type BeastDeck = { monsters: string[]; spells: string[] };

function playableMonster(id: string) {
  return Boolean(monsterCard(id)) && !outside.has(id);
}

export function deckIssues(deck: BeastDeck): string | null {
  const monsters = deck.monsters.filter(playableMonster);
  const spells = deck.spells.filter((id) => spellCard(id));
  if (new Set(monsters).size !== monsters.length || new Set(spells).size !== spells.length) return "Mỗi lá chỉ được một bản.";
  if (spells.filter((id) => spellCard(id)?.env).length > 1) return "Chỉ được một lá môi trường.";
  if (!deckLegal(monsters.length, spells.length)) return "Cần đúng 24 lá: quái 12–15, phép 9–12.";
  return null;
}

export type DeckSide = { sign: "" | "+" | "-"; n: number; bad: boolean };

export function deckBalance(deck: BeastDeck): { monster: DeckSide; spell: DeckSide } {
  const side = (count: number, min: number, max: number): DeckSide => {
    if (count < min) return { sign: "-", n: min - count, bad: true };
    if (count > max) return { sign: "+", n: count - max, bad: true };
    return { sign: "+", n: count - min, bad: false };
  };
  return { monster: side(deck.monsters.length, 12, 15), spell: side(deck.spells.length, 9, 12) };
}

function clean(deck: Partial<BeastDeck> | undefined): BeastDeck {
  return {
    monsters: (deck?.monsters ?? []).filter(playableMonster),
    spells: (deck?.spells ?? []).filter((id) => spellCard(id)),
  };
}

export function loadDeck(): BeastDeck {
  if (typeof localStorage === "undefined") return DEFAULT_DECK;
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return DEFAULT_DECK;
    const deck = clean(JSON.parse(raw) as Partial<BeastDeck>);
    if (deck.monsters.length + deck.spells.length === 0) return DEFAULT_DECK;
    return deck;
  } catch {
    return DEFAULT_DECK;
  }
}

export function saveDeck(deck: BeastDeck) {
  localStorage.setItem(KEY, JSON.stringify({ monsters: deck.monsters, spells: deck.spells }));
}
