import { artSrc, spellCard, spellSrc, type MonsterCard } from "@/lib/catalog";
import { tr, useLang } from "@/lib/i18n";
import { loadCard, loadSpell, type CardKey, type SpellKey, type Spot } from "@/lib/layouts";

function NewMark({ spot }: { spot: Spot }) {
  return (
    <span
      className="socket is-new"
      style={{
        left: `${spot.x}%`,
        top: `${spot.y}%`,
        width: `${spot.width}%`,
        height: `${spot.height}%`,
      }}
    >
      <img src="/mark-moi.png" alt="" draggable={false} />
    </span>
  );
}

export function CardFace({
  monster,
  spellId,
  level = 1,
  dim = false,
  selected = false,
  hideStats = false,
  showNew = false,
  layout,
  spellLayout,
  live,
  gems,
}: {
  monster?: MonsterCard | null;
  spellId?: string;
  level?: number;
  dim?: boolean;
  selected?: boolean;
  hideStats?: boolean;
  showNew?: boolean;
  layout?: Record<CardKey, Spot>;
  spellLayout?: Record<SpellKey, Spot>;
  live?: { name: string; atk: number; def: number; mdef: number; hp: number };
  gems?: number | string;
}) {
  const spell = spellId ? spellCard(spellId) : undefined;
  useLang();
  const spots = layout ?? loadCard();
  const spellSpots = spellLayout ?? loadSpell();
  const tier = monster ? monsterTier(monster.stars) : spell ? spellTier(spell.gems) : "";
  const pin = (spot: Spot, value: string | number, name = false) =>
    hideStats || (!name && value === 0) ? null : (
      <span
        className={`socket${name ? " is-name" : ""}`}
        style={{
          left: `${spot.x}%`,
          top: `${spot.y}%`,
          width: `${spot.width}%`,
          height: `${spot.height}%`,
          fontSize: `${spot.size}cqw`,
        }}
      >
        {value}
      </span>
    );
  return (
    <div className={`card${spell ? " is-spell" : ""}${tier}${dim ? " is-dim" : ""}${selected ? " is-selected" : ""}`}>
      {monster ? (
        artSrc(monster.id, level) ? <img className="art" src={artSrc(monster.id, level)} alt="" draggable={false} /> : null
      ) : spell ? (
        <img className="art" src={spellSrc(spell.id)} alt="" draggable={false} />
      ) : null}
      <img className="frame" src={spell ? "/spell-frame.png" : "/card-frame.png"} alt="" draggable={false} />
      {monster ? (
        <>
          {pin(spots.stars, monster.stars)}
          {pin(spots.gems, gems ?? monster.gems)}
          {pin(spots.def, live?.def ?? monster.def)}
          {pin(spots.mdef, live?.mdef ?? monster.mdef)}
          {pin(spots.atk, live?.atk ?? monster.atk)}
          {pin(spots.hp, live?.hp ?? monster.hp)}
          {pin(spots.name, tr(live?.name ?? monster.name), true)}
          {showNew ? <NewMark spot={spots.fresh} /> : null}
        </>
      ) : spell ? (
        <>
          {pin(spellSpots.gems, gems ?? spell.gems)}
          {pin(spellSpots.name, tr(spell.name), true)}
          {showNew ? <NewMark spot={spellSpots.fresh} /> : null}
        </>
      ) : null}
    </div>
  );
}

function monsterTier(stars: number) {
  if (stars >= 5) return " is-tier-black";
  if (stars >= 4) return " is-tier-purple";
  if (stars === 3) return " is-tier-red";
  if (stars === 2) return " is-tier-yellow";
  return "";
}

function spellTier(gems: number) {
  if (gems >= 3) return " is-tier-purple";
  if (gems === 2) return " is-tier-red";
  if (gems === 1) return " is-tier-orange";
  return "";
}
