import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { tr, useLang } from "@/lib/i18n";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const [wins, setWins] = useState(0);
  useLang();
  useEffect(() => {
    setWins(Number(localStorage.getItem("clash-wins") ?? "0") || 0);
  }, []);
  return (
    <main className="home">
      <div>
        <div className="poster">
          <img src="/title.png" alt="Clash of the Beasts" />
          <Link to="/modes" className="hit hit-play" aria-label="Vào đấu trường" />
          <Link to="/deck" className="hit hit-deck" aria-label="Xây bộ bài" />
        </div>
        {wins > 0 ? <p className="win-note">{tr("Thành đã phá")}: {wins}</p> : null}
        <p className="home-links">
          <Link to="/tune">{tr("Tuỳ chỉnh bàn và lá")}</Link>
          <Link to="/watch">{tr("Thông tin")}</Link>
        </p>
      </div>
    </main>
  );
}
